/**
 * Client-side replacement for the Express API (server.ts). This deployment
 * (Netlify static hosting) cannot run that Node server, so every read/write
 * that used to hit `/api/...` now talks to Firestore directly, guarded by
 * firestore.rules instead of server-side route checks.
 */
import { db } from './firebase';
import {
  collection,
  doc,
  getDoc,
  getDocs,
  addDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  writeBatch,
  query,
  orderBy,
  limit as fsLimit,
  increment,
  arrayUnion,
  serverTimestamp
} from 'firebase/firestore';
import {
  DigitalPlatform,
  Course,
  EngineeringResource,
  AuthorityAccounts,
  AppNotification,
  NewsActivity,
  NewsComment,
  ActivityPingPayload,
  HeartbeatPayload,
  UserTrackLog
} from '../types';

const genId = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36);

// ---------------------------------------------------------------------------
// Platforms / Courses / Resources — simple admin-write, public-read collections
// ---------------------------------------------------------------------------
async function fetchCollectionOrdered<T>(name: string): Promise<T[]> {
  const snap = await getDocs(collection(db, name));
  const rows = snap.docs.map(d => ({ id: d.id, ...d.data() } as any));
  rows.sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
  return rows as T[];
}

export const fetchPlatforms = () => fetchCollectionOrdered<DigitalPlatform>('platforms');
export const fetchCourses = () => fetchCollectionOrdered<Course>('courses');
export const fetchResources = () => fetchCollectionOrdered<EngineeringResource>('resources');

export async function fetchAccounts(): Promise<AuthorityAccounts | null> {
  const snap = await getDoc(doc(db, 'accounts', 'main'));
  return snap.exists() ? (snap.data() as AuthorityAccounts) : null;
}
export async function updateAccounts(acc: AuthorityAccounts) {
  await setDoc(doc(db, 'accounts', 'main'), acc, { merge: true });
}

export async function createPlatform(p: { name: string; url: string; image?: string; description?: string }) {
  await addDoc(collection(db, 'platforms'), { ...p, order: Date.now() });
}
export async function updatePlatform(id: string, updated: Partial<DigitalPlatform>) {
  await updateDoc(doc(db, 'platforms', id), updated as any);
}
export async function deletePlatform(id: string) {
  await deleteDoc(doc(db, 'platforms', id));
}
export async function reorderPlatforms(ids: string[]) {
  const batch = writeBatch(db);
  ids.forEach((id, i) => batch.update(doc(db, 'platforms', id), { order: i }));
  await batch.commit();
}

export async function createCourse(c: { title: string; url: string; description?: string; instructor?: string }) {
  await addDoc(collection(db, 'courses'), { ...c, order: Date.now(), addedAt: new Date().toISOString() });
}
export async function updateCourse(id: string, updated: Partial<Course>) {
  await updateDoc(doc(db, 'courses', id), updated as any);
}
export async function deleteCourse(id: string) {
  await deleteDoc(doc(db, 'courses', id));
}
export async function reorderCourses(ids: string[]) {
  const batch = writeBatch(db);
  ids.forEach((id, i) => batch.update(doc(db, 'courses', id), { order: i }));
  await batch.commit();
}

export async function createResource(r: { title: string; category: string; description: string; url: string; fileName: string; fileSize: number }) {
  await addDoc(collection(db, 'resources'), { ...r, order: Date.now(), addedAt: new Date().toISOString() });
}
export async function updateResource(id: string, updated: Partial<EngineeringResource>) {
  await updateDoc(doc(db, 'resources', id), updated as any);
}
export async function deleteResource(id: string) {
  await deleteDoc(doc(db, 'resources', id));
}
export async function reorderResources(ids: string[]) {
  const batch = writeBatch(db);
  ids.forEach((id, i) => batch.update(doc(db, 'resources', id), { order: i }));
  await batch.commit();
}

// ---------------------------------------------------------------------------
// Activity tracking (replaces /api/track/activity + /api/track/heartbeat)
// ---------------------------------------------------------------------------
export async function logActivity(currentUserName: string, currentUserEmail: string, role: 'admin' | 'student', payload: ActivityPingPayload) {
  const ref = doc(db, 'trackingLogs', payload.userId);
  const snap = await getDoc(ref);
  const entry = {
    action: payload.action,
    timestamp: new Date().toISOString(),
    details: payload.details || ''
  };
  if (!snap.exists()) {
    const initial: UserTrackLog = {
      userId: payload.userId,
      userName: currentUserName,
      userEmail: currentUserEmail,
      role,
      registrationDate: new Date().toISOString(),
      lastActive: new Date().toISOString(),
      dailyUsageCount: 1,
      totalActiveTimeSeconds: 0,
      platformStays: {},
      activityTimeline: [entry]
    };
    await setDoc(ref, initial);
  } else {
    await updateDoc(ref, {
      lastActive: new Date().toISOString(),
      dailyUsageCount: increment(1),
      activityTimeline: arrayUnion(entry)
    });
  }
}

export async function logHeartbeat(payload: HeartbeatPayload) {
  const ref = doc(db, 'trackingLogs', payload.userId);
  const snap = await getDoc(ref);
  if (!snap.exists()) return; // no session logged yet, ignore stray heartbeat
  const data = snap.data() as UserTrackLog;
  const stays = { ...(data.platformStays || {}) };
  if (payload.platformId) {
    const existing = stays[payload.platformId] || { platformId: payload.platformId, platformName: payload.platformName || '', entriesCount: 0, durationSeconds: 0 };
    stays[payload.platformId] = {
      ...existing,
      platformName: payload.platformName || existing.platformName,
      durationSeconds: (existing.durationSeconds || 0) + payload.seconds
    };
  }
  await updateDoc(ref, {
    lastActive: new Date().toISOString(),
    totalActiveTimeSeconds: increment(payload.seconds),
    platformStays: stays
  });
}

export async function fetchTrackingLogs(): Promise<UserTrackLog[]> {
  const snap = await getDocs(collection(db, 'trackingLogs'));
  return snap.docs.map(d => d.data() as UserTrackLog);
}

// ---------------------------------------------------------------------------
// Audit logs (replaces /api/admin/audit-logs)
// ---------------------------------------------------------------------------
export async function logAudit(action: string, userId: string, userName: string, userEmail: string, details: string) {
  try {
    await addDoc(collection(db, 'auditLogs'), {
      userId,
      userName,
      userEmail,
      action,
      timestamp: new Date().toISOString(),
      details,
      userAgent: navigator.userAgent
    });
  } catch (err) {
    // Non-fatal — never block login/registration if the audit write fails.
    console.warn('Audit log write failed:', err);
  }
}

export async function fetchAuditLogs(max = 300) {
  const snap = await getDocs(query(collection(db, 'auditLogs'), orderBy('timestamp', 'desc'), fsLimit(max)));
  return snap.docs.map(d => ({ id: d.id, ...d.data() }));
}

// ---------------------------------------------------------------------------
// Admin dashboard stats (replaces /api/admin/stats)
// ---------------------------------------------------------------------------
export async function fetchAdminStats() {
  const [usersSnap, trackingLogs, auditLogs] = await Promise.all([
    getDocs(collection(db, 'users')),
    fetchTrackingLogs(),
    fetchAuditLogs(1000)
  ]);

  const users = usersSnap.docs.map(d => ({ id: d.id, ...d.data() } as any));
  const totalUsers = users.length;
  const totalStudents = users.filter(u => u.role === 'student').length;

  const now = Date.now();
  const dayMs = 24 * 60 * 60 * 1000;
  const activeToday = trackingLogs.filter(l => now - new Date(l.lastActive).getTime() < dayMs).length;
  const activeThisWeek = trackingLogs.filter(l => now - new Date(l.lastActive).getTime() < 7 * dayMs).length;
  const totalLogins = trackingLogs.reduce((sum, l) => sum + (l.dailyUsageCount || 0), 0);
  const totalRegistrations = auditLogs.filter((a: any) => a.action === 'REGISTRATION').length;

  const byAcademicYear: Record<string, number> = {};
  users.forEach(u => {
    const key = u.academicYear || 'غير محدد';
    byAcademicYear[key] = (byAcademicYear[key] || 0) + 1;
  });

  // Last 14 days of registrations + logins for the trend chart
  const dailyMap: Record<string, number> = {};
  const days: string[] = [];
  for (let i = 13; i >= 0; i--) {
    const d = new Date(now - i * dayMs);
    const key = d.toISOString().slice(0, 10);
    days.push(key);
    dailyMap[key] = 0;
  }
  auditLogs.forEach((a: any) => {
    if (a.action !== 'REGISTRATION' && a.action !== 'LOGIN_SUCCESS') return;
    const key = String(a.timestamp).slice(0, 10);
    if (key in dailyMap) dailyMap[key] += 1;
  });
  const dailySeries = days.map(day => ({ date: day, count: dailyMap[day] }));

  return {
    generatedAt: new Date().toISOString(),
    totalUsers,
    totalStudents,
    activeToday,
    activeThisWeek,
    totalRegistrations,
    totalLogins,
    dailySeries,
    byAcademicYear
  };
}

// ---------------------------------------------------------------------------
// Notifications (replaces /api/notifications*)
// ---------------------------------------------------------------------------
export async function fetchNotifications(): Promise<AppNotification[]> {
  const snap = await getDocs(query(collection(db, 'notifications'), orderBy('createdAt', 'desc'), fsLimit(200)));
  return snap.docs.map(d => ({ id: d.id, ...d.data() } as AppNotification));
}
export async function createNotification(data: Omit<AppNotification, 'id' | 'createdAt'>) {
  await addDoc(collection(db, 'notifications'), { ...data, createdAt: new Date().toISOString(), isRead: [] });
}
export async function deleteNotification(id: string) {
  await deleteDoc(doc(db, 'notifications', id));
}
export async function markNotificationRead(id: string, userId: string) {
  await updateDoc(doc(db, 'notifications', id), { isRead: arrayUnion(userId) });
}
export async function markAllNotificationsRead(ids: string[], userId: string) {
  const batch = writeBatch(db);
  ids.forEach(id => batch.update(doc(db, 'notifications', id), { isRead: arrayUnion(userId) }));
  await batch.commit();
}

// ---------------------------------------------------------------------------
// News + comments (replaces /api/news*)
// ---------------------------------------------------------------------------
export async function fetchNews(): Promise<NewsActivity[]> {
  const snap = await getDocs(query(collection(db, 'news'), orderBy('createdAt', 'desc'), fsLimit(100)));
  return snap.docs.map(d => ({ id: d.id, ...d.data() } as NewsActivity));
}
export async function createNews(data: { title: string; content: string; imageUrl?: string; videoUrl?: string }) {
  await addDoc(collection(db, 'news'), { ...data, createdAt: new Date().toISOString(), comments: [] });
}
export async function deleteNews(id: string) {
  await deleteDoc(doc(db, 'news', id));
}
export async function addNewsComment(postId: string, comment: { userName: string; userEmail: string; content: string }): Promise<NewsComment> {
  const newComment: NewsComment = { id: genId(), createdAt: new Date().toISOString(), ...comment };
  await updateDoc(doc(db, 'news', postId), { comments: arrayUnion(newComment) });
  return newComment;
}
export async function deleteNewsComment(postId: string, commentId: string) {
  const ref = doc(db, 'news', postId);
  const snap = await getDoc(ref);
  if (!snap.exists()) return;
  const data = snap.data() as NewsActivity;
  const filtered = (data.comments || []).filter(c => c.id !== commentId);
  await updateDoc(ref, { comments: filtered });
}
