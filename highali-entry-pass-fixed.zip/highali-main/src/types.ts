/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'student';
  academicYear?: string;
  createdAt: string;
  lastActive?: string;
  emailVerified?: boolean;
  twoFactorEnabled?: boolean;
  twoFactorSecret?: string;
  isTemp2FAPassed?: boolean;
  token?: string;
  // Server-side only: salted+hashed 4-digit PIN for username-only accounts.
  // Never sent to the client.
  pin?: string;
}

export interface DigitalPlatform {
  id: string;
  name: string;
  url: string;
  image: string; // Base64 or URL
  description: string;
  isSystem?: boolean; // If it's one of the initial platforms
}

export interface Course {
  id: string;
  title: string;
  url: string;
  description?: string;
  instructor?: string;
  addedAt: string;
}

export interface EngineeringResource {
  id: string;
  title: string;
  category: string;
  description: string;
  url: string; // Can be a storage link or Google Drive link
  fileName: string;
  fileSize: number; // in bytes (supports 400MB+)
  addedAt: string;
}

export interface AuthorityAccounts {
  telegram: string;
  instagram: string;
  facebook: string;
  whatsapp: string;
  youtube: string;
  linkedin: string;
  website: string;
  telegramGot: string;
  instagramGot: string;
  telegramTrainee: string;
}

export interface PageActivity {
  pageName: string;
  timestamp: string;
}

export interface PlatformStay {
  platformId: string;
  platformName: string;
  entriesCount: number;
  durationSeconds: number; // calculated active duration
}

export interface UserTrackLog {
  userId: string;
  userName: string;
  userEmail: string;
  role: 'admin' | 'student';
  registrationDate: string;
  lastActive: string;
  dailyUsageCount: number; // total page clicks
  totalActiveTimeSeconds: number; // total heartbeat sum
  platformStays: Record<string, PlatformStay>; // platformId -> stats
  activityTimeline: {
    action: string;
    timestamp: string;
    details?: string;
  }[];
}

export interface ActivityPingPayload {
  userId: string;
  action: string; // e.g., 'view_page', 'click_platform', 'logout'
  pageName?: string;
  platformId?: string;
  platformName?: string;
  details?: string;
}

export interface HeartbeatPayload {
  userId: string;
  platformId?: string; // if spent inside a digital platform
  platformName?: string;
  seconds: number;
}

export interface AppNotification {
  id: string;
  title: string;
  titleEn?: string;
  description: string;
  descriptionEn?: string;
  type: 'update' | 'alert' | 'announcement' | 'maintenance' | 'course' | 'resource' | 'platform' | 'general';
  targetUsers?: string | string[];
  isRead?: string[];
  createdAt: string;
  createdBy?: string;
}

export interface NewsComment {
  id: string;
  userName: string;
  userEmail: string;
  content: string;
  createdAt: string;
}

export interface NewsActivity {
  id: string;
  title: string;
  content: string;
  imageUrl?: string;
  videoUrl?: string;
  createdAt: string;
  comments: NewsComment[];
}


