/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Bell, BellRing, Award, BookOpen, Monitor, Info, X, Check, ShieldAlert } from 'lucide-react';

export interface ToastItem {
  id: string;
  title: string;
  titleEn?: string;
  description: string;
  descriptionEn?: string;
  type: 'course' | 'resource' | 'platform' | 'general' | 'success' | 'error';
  duration?: number; // milleseconds, default 6000
}

interface ToastContainerProps {
  lang: 'ar' | 'en' | 'de' | 'es';
}

// Global utility helper to trigger a toast from anywhere in the codebase!
export function triggerToast(toast: Omit<ToastItem, 'id'> & { id?: string }) {
  const event = new CustomEvent('app-toast', {
    detail: {
      ...toast,
      id: toast.id || 'toast-' + Math.random().toString(36).substr(2, 9)
    }
  });
  window.dispatchEvent(event);
}

export default function ToastContainer({ lang }: ToastContainerProps) {
  const [toasts, setToasts] = useState<ToastItem[]>([]);
  const isAr = lang === 'ar';

  useEffect(() => {
    const handleToastEvent = (e: Event) => {
      const customEvent = e as CustomEvent<ToastItem>;
      if (customEvent.detail) {
        // Play sound effect for positive/update events
        if (customEvent.detail.type !== 'error') {
          triggerModernChime();
        }
        
        setToasts(prev => {
          // Prevent duplicates by ID
          if (prev.some(t => t.id === customEvent.detail.id)) return prev;
          return [...prev, customEvent.detail];
        });
      }
    };

    window.addEventListener('app-toast', handleToastEvent);
    return () => {
      window.removeEventListener('app-toast', handleToastEvent);
    };
  }, []);

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  // Modern synthesized notification chime
  const triggerModernChime = () => {
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      if (!audioCtx) return;
      
      const now = audioCtx.currentTime;
      
      // We will make a pleasant dual-chime sound (synthesizer)
      const osc1 = audioCtx.createOscillator();
      const osc2 = audioCtx.createOscillator();
      const gainNode = audioCtx.createGain();
      
      osc1.type = 'sine';
      osc2.type = 'triangle';
      
      // Chime note frequencies (E.g., G5 then C6 for perfect fourth resolution)
      osc1.frequency.setValueAtTime(783.99, now); // G5
      osc1.frequency.setValueAtTime(1046.50, now + 0.1); // C6
      
      osc2.frequency.setValueAtTime(783.99, now); // G5 sidetone
      osc2.frequency.setValueAtTime(1046.50, now + 0.1);
      
      gainNode.gain.setValueAtTime(0.001, now);
      gainNode.gain.linearRampToValueAtTime(0.08, now + 0.05);
      gainNode.gain.exponentialRampToValueAtTime(0.001, now + 0.5);
      
      osc1.connect(gainNode);
      osc2.connect(gainNode);
      gainNode.connect(audioCtx.destination);
      
      osc1.start(now);
      osc2.start(now);
      
      osc1.stop(now + 0.55);
      osc2.stop(now + 0.55);
    } catch (e) {
      // Browsers block automatic audio unless user has interacted, which is safely handled here
      console.warn('Toast synthesizer audio blocked or unsupported.', e);
    }
  };

  return (
    <div 
      className={`fixed bottom-4 z-[9999] flex flex-col gap-3 max-w-full px-4 text-right pointer-events-none ${
        isAr ? 'left-0 sm:left-4 items-start' : 'right-0 sm:right-4 items-end'
      }`}
      dir={isAr ? 'rtl' : 'ltr'}
      id="global-toast-container"
    >
      <AnimatePresence>
        {toasts.map((toast) => (
          <ToastCard 
            key={toast.id} 
            toast={toast} 
            isAr={isAr} 
            onClose={() => removeToast(toast.id)} 
          />
        ))}
      </AnimatePresence>
    </div>
  );
}

// Individual Toast Card for complex interactive and hover pausing timer
function ToastCard({ toast, isAr, onClose }: { toast: ToastItem; isAr: boolean; onClose: () => void; key?: string }) {
  const duration = toast.duration || 6000;
  const [timeLeft, setTimeLeft] = useState(duration);
  const [isHovered, setIsHovered] = useState(false);

  useEffect(() => {
    if (timeLeft <= 0) {
      onClose();
    }
  }, [timeLeft, onClose]);

  useEffect(() => {
    if (isHovered) return;

    const step = 100;
    const interval = setInterval(() => {
      setTimeLeft(prev => Math.max(0, prev - step));
    }, step);

    return () => {
      clearInterval(interval);
    };
  }, [isHovered]);

  const progressPercent = (timeLeft / duration) * 100;

  // Icon picking mapping
  const getIcon = () => {
    switch (toast.type) {
      case 'platform':
        return {
          Icon: Monitor,
          colorClass: 'text-emerald-500 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-100/30'
        };
      case 'course':
        return {
          Icon: Award,
          colorClass: 'text-teal-600 bg-teal-50 dark:bg-teal-950/40 border border-teal-100/30'
        };
      case 'resource':
        return {
          Icon: BookOpen,
          colorClass: 'text-cyan-500 bg-cyan-50 dark:bg-cyan-950/40 border border-cyan-100/30'
        };
      case 'success':
        return {
          Icon: Check,
          colorClass: 'text-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-100/30'
        };
      case 'error':
        return {
          Icon: ShieldAlert,
          colorClass: 'text-red-500 bg-red-50 dark:bg-red-950/40 border border-red-100/30'
        };
      default:
        return {
          Icon: Info,
          colorClass: 'text-amber-500 bg-amber-50 dark:bg-amber-950/40 border border-amber-100/30'
        };
    }
  };

  const { Icon, colorClass } = getIcon();
  const displayTitle = isAr ? toast.title : (toast.titleEn || toast.title);
  const displayDesc = isAr ? toast.description : (toast.descriptionEn || toast.description);

  return (
    <motion.div
      initial={{ opacity: 0, y: 50, scale: 0.9, x: isAr ? -30 : 30 }}
      animate={{ opacity: 1, y: 0, scale: 1, x: 0 }}
      exit={{ opacity: 0, scale: 0.85, transition: { duration: 0.2 } }}
      whileHover={{ y: -2 }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className="pointer-events-auto relative w-80 sm:w-96 rounded-2xl border border-slate-200/50 dark:border-slate-800/60 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md p-4 shadow-xl overflow-hidden flex gap-3 text-start cursor-default select-none"
      id={`toast-item-${toast.id}`}
    >
      {/* Category Indicator Icon */}
      <span className={`p-2.5 h-10 w-10 shrink-0 rounded-xl flex items-center justify-center ${colorClass}`}>
        <Icon className="h-5 w-5" />
      </span>

      {/* Text Info */}
      <div className="flex-1 min-w-0 pr-1 space-y-0.5">
        <h4 className="text-[12px] font-black text-slate-900 dark:text-white leading-snug">
          {displayTitle}
        </h4>
        <p className="text-[10px] text-slate-500 dark:text-slate-400 leading-normal">
          {displayDesc}
        </p>
      </div>

      {/* Manual Dismiss Button */}
      <button
        onClick={onClose}
        className="p-1 rounded-lg h-7 w-7 flex items-center justify-center text-slate-400 hover:text-slate-650 dark:hover:text-slate-200 hover:bg-slate-100/55 dark:hover:bg-slate-800/40 transition cursor-pointer"
        aria-label="Dismiss toast"
      >
        <X className="h-4 w-4" />
      </button>

      {/* Shimmering bottom animated timeline bar */}
      <div className="absolute bottom-0 left-0 right-0 h-[3px] bg-slate-100/40 dark:bg-slate-850/40">
        <div 
          className={`h-full transition-all duration-100 ${
            toast.type === 'error' ? 'bg-red-500' :
            toast.type === 'success' ? 'bg-emerald-500' :
            toast.type === 'platform' ? 'bg-emerald-500' :
            toast.type === 'course' ? 'bg-teal-500' :
            toast.type === 'resource' ? 'bg-cyan-500' : 'bg-teal-500'
          }`}
          style={{ width: `${progressPercent}%` }}
        />
      </div>
    </motion.div>
  );
}
