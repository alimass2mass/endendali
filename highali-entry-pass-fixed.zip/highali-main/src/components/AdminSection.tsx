/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { 
  Users, Activity, Clock, Monitor, RefreshCw, Calendar, Trash2, 
  Eye, Edit, Save, ArrowUp, ArrowDown, Shield, Award, BookOpen, FileText, HardDrive, Plus,
  Bell, Send, Mail, CheckSquare, Square, Wrench, History, LogIn, BarChart3, Download
} from 'lucide-react';
import { User, UserTrackLog, DigitalPlatform, Course, EngineeringResource } from '../types';
import { motion } from 'motion/react';
import { LanguageType } from '../locales';
import * as fsApi from '../lib/firestoreApi';
import { auth } from '../lib/firebase';
import { EmailAuthProvider, reauthenticateWithCredential, updatePassword } from 'firebase/auth';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';

interface AdminSectionProps {
  currentUser: User | null;
  platforms: DigitalPlatform[];
  courses: Course[];
  resources: EngineeringResource[];
  onAddPlatform: (platform: { name: string; url: string; image?: string; description?: string }) => void;
  onEditPlatform: (id: string, updated: Partial<DigitalPlatform>) => void;
  onDeletePlatform: (id: string) => void;
  onReorderPlatforms?: (orderedIds: string[]) => void;
  
  onAddCourse: (course: { title: string; url: string; description?: string; instructor?: string }) => void;
  onEditCourse: (id: string, updated: Partial<Course>) => void;
  onDeleteCourse: (id: string) => void;
  onReorderCourses?: (orderedIds: string[]) => void;
  
  onAddResource: (resource: { title: string; category: string; description: string; url: string; fileName: string; fileSize: number }) => void;
  onEditResource: (id: string, updated: Partial<EngineeringResource>) => void;
  onDeleteResource: (id: string) => void;
  onReorderResources?: (orderedIds: string[]) => void;
  
  lang: LanguageType;
  t: any;
}

export default function AdminSection({
  currentUser,
  platforms,
  courses,
  resources,
  onAddPlatform,
  onEditPlatform,
  onDeletePlatform,
  onReorderPlatforms,
  onAddCourse,
  onEditCourse,
  onDeleteCourse,
  onReorderCourses,
  onAddResource,
  onEditResource,
  onDeleteResource,
  onReorderResources,
  lang,
  t
}: AdminSectionProps) {
  const [activeTab, setActiveTab] = useState<'tracking' | 'auditlog' | 'stats' | 'platforms' | 'courses' | 'resources' | 'security' | 'notifications'>('tracking');
  const [logsList, setLogsList] = useState<UserTrackLog[]>([]);
  const [auditLogs, setAuditLogs] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedUserLog, setSelectedUserLog] = useState<UserTrackLog | null>(null);
  const [searchUserQuery, setSearchUserQuery] = useState('');

  // States for notifications management
  const [notifTitle, setNotifTitle] = useState('');
  const [notifMessage, setNotifMessage] = useState('');
  const [notifType, setNotifType] = useState<'update' | 'alert' | 'announcement' | 'maintenance'>('update');
  const [notifTarget, setNotifTarget] = useState<'all' | 'specific'>('all');
  const [notifSelectedUsers, setNotifSelectedUsers] = useState<string[]>([]);
  const [notifSendMethod, setNotifSendMethod] = useState<'internal' | 'email' | 'both'>('both');
  const [notifHistory, setNotifHistory] = useState<any[]>([]);
  const [isPreviewing, setIsPreviewing] = useState(false);
  const [isSendingNotif, setIsSendingNotif] = useState(false);

  // States for platforms management
  const [platName, setPlatName] = useState('');
  const [platUrl, setPlatUrl] = useState('');
  const [platDesc, setPlatDesc] = useState('');
  const [platImg, setPlatImg] = useState('');
  const [editingPlatId, setEditingPlatId] = useState<string | null>(null);

  // States for courses management
  const [courseTitle, setCourseTitle] = useState('');
  const [courseUrl, setCourseUrl] = useState('');
  const [courseDesc, setCourseDesc] = useState('');
  const [courseInstructor, setCourseInstructor] = useState('');
  const [editingCourseId, setEditingCourseId] = useState<string | null>(null);

  // States for resources management
  const [resTitle, setResTitle] = useState('');
  const [resCategory, setResCategory] = useState('Core Textbooks');
  const [resDesc, setResDesc] = useState('');
  const [resUrl, setResUrl] = useState('');
  const [resFileName, setResFileName] = useState('');
  const [resFileSizeMB, setResFileSizeMB] = useState('420');
  const [editingResId, setEditingResId] = useState<string | null>(null);

  // States for security tab
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [pwdError, setPwdError] = useState('');
  const [pwdSuccess, setPwdSuccess] = useState('');
  const [pwdLoading, setPwdLoading] = useState(false);

  // States for the exportable statistics report
  const [statsData, setStatsData] = useState<any>(null);
  const [statsLoading, setStatsLoading] = useState(false);
  const [isExportingPdf, setIsExportingPdf] = useState(false);
  const statsReportRef = useRef<HTMLDivElement>(null);

  const fetchStats = async () => {
    setStatsLoading(true);
    try {
      const data = await fsApi.fetchAdminStats();
      setStatsData(data);
    } catch (err) {
      console.error('Error fetching stats:', err);
    } finally {
      setStatsLoading(false);
    }
  };

  const handleExportStatsPdf = async () => {
    if (!statsReportRef.current) return;
    setIsExportingPdf(true);
    try {
      const [{ default: html2canvas }, { jsPDF }] = await Promise.all([
        import('html2canvas'),
        import('jspdf')
      ]);
      const canvas = await html2canvas(statsReportRef.current, { scale: 2, backgroundColor: '#ffffff' });
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF({ orientation: 'portrait', unit: 'px', format: [canvas.width, canvas.height] });
      pdf.addImage(imgData, 'PNG', 0, 0, canvas.width, canvas.height);
      pdf.save(`platform-stats-report-${new Date().toISOString().slice(0, 10)}.pdf`);
    } catch (err) {
      console.error('Error exporting stats PDF:', err);
    } finally {
      setIsExportingPdf(false);
    }
  };

  // Load backend activity logs
  const fetchLogs = async () => {
    setIsLoading(true);
    try {
      const data = await fsApi.fetchTrackingLogs();
      setLogsList(data);
    } catch (err) {
      console.error('Error fetching logs:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchAuditLogs = async () => {
    setIsLoading(true);
    try {
      const data = await fsApi.fetchAuditLogs();
      setAuditLogs(data);
    } catch (err) {
      console.error('Error fetching audit logs:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchNotifHistory = async () => {
    setIsLoading(true);
    try {
      const data = await fsApi.fetchNotifications();
      setNotifHistory(data);
    } catch (err) {
      console.error('Error fetching notifications history:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (activeTab === 'tracking') {
      fetchLogs();
    } else if (activeTab === 'auditlog') {
      fetchAuditLogs();
    } else if (activeTab === 'stats') {
      fetchStats();
    } else if (activeTab === 'notifications') {
      fetchNotifHistory();
      fetchLogs(); // Needed so logsList is populated to select specific users
    }
  }, [activeTab]);

  // Platforms form submit handler
  const handleAddPlatSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!platName.trim() || !platUrl.trim()) return;

    if (editingPlatId) {
      onEditPlatform(editingPlatId, {
        name: platName,
        url: platUrl,
        image: platImg || undefined,
        description: platDesc
      });
      setEditingPlatId(null);
    } else {
      onAddPlatform({
        name: platName,
        url: platUrl,
        image: platImg || undefined,
        description: platDesc
      });
    }

    // Reset
    setPlatName('');
    setPlatUrl('');
    setPlatDesc('');
    setPlatImg('');
  };

  const handleStartEditPlatform = (p: DigitalPlatform) => {
    setEditingPlatId(p.id);
    setPlatName(p.name);
    setPlatUrl(p.url);
    setPlatDesc(p.description);
    setPlatImg(p.image);
  };

  const handleMovePlatformUp = (platformId: string) => {
    const trueIndex = platforms.findIndex(p => p.id === platformId);
    if (trueIndex <= 0) return;
    const reordered = [...platforms];
    const temp = reordered[trueIndex];
    reordered[trueIndex] = reordered[trueIndex - 1];
    reordered[trueIndex - 1] = temp;
    if (onReorderPlatforms) {
      onReorderPlatforms(reordered.map(p => p.id));
    }
  };

  const handleMovePlatformDown = (platformId: string) => {
    const trueIndex = platforms.findIndex(p => p.id === platformId);
    if (trueIndex === -1 || trueIndex === platforms.length - 1) return;
    const reordered = [...platforms];
    const temp = reordered[trueIndex];
    reordered[trueIndex] = reordered[trueIndex + 1];
    reordered[trueIndex + 1] = temp;
    if (onReorderPlatforms) {
      onReorderPlatforms(reordered.map(p => p.id));
    }
  };

  // Courses form submit handler
  const handleAddCourseSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!courseTitle.trim() || !courseUrl.trim()) return;

    if (editingCourseId) {
      if (onEditCourse) {
        onEditCourse(editingCourseId, {
          title: courseTitle,
          url: courseUrl,
          description: courseDesc,
          instructor: courseInstructor || undefined
        });
      }
      setEditingCourseId(null);
    } else {
      onAddCourse({
        title: courseTitle,
        url: courseUrl,
        description: courseDesc,
        instructor: courseInstructor || undefined
      });
    }

    // Reset
    setCourseTitle('');
    setCourseUrl('');
    setCourseDesc('');
    setCourseInstructor('');
  };

  const handleStartEditCourse = (c: Course) => {
    setEditingCourseId(c.id);
    setCourseTitle(c.title);
    setCourseUrl(c.url);
    setCourseDesc(c.description || '');
    setCourseInstructor(c.instructor || '');
  };

  const handleMoveCourseUp = (courseId: string) => {
    const trueIndex = courses.findIndex(c => c.id === courseId);
    if (trueIndex <= 0) return;
    const reordered = [...courses];
    const temp = reordered[trueIndex];
    reordered[trueIndex] = reordered[trueIndex - 1];
    reordered[trueIndex - 1] = temp;
    if (onReorderCourses) {
      onReorderCourses(reordered.map(c => c.id));
    }
  };

  const handleMoveCourseDown = (courseId: string) => {
    const trueIndex = courses.findIndex(c => c.id === courseId);
    if (trueIndex === -1 || trueIndex === courses.length - 1) return;
    const reordered = [...courses];
    const temp = reordered[trueIndex];
    reordered[trueIndex] = reordered[trueIndex + 1];
    reordered[trueIndex + 1] = temp;
    if (onReorderCourses) {
      onReorderCourses(reordered.map(c => c.id));
    }
  };

  // Resources form submit handler
  const handleAddResourceSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!resTitle.trim() || !resUrl.trim() || !resFileName.trim()) return;

    const finalSizeInBytes = Math.round(Number(resFileSizeMB) * 1024 * 1024) || 0;

    if (editingResId) {
      if (onEditResource) {
        onEditResource(editingResId, {
          title: resTitle,
          category: resCategory,
          description: resDesc,
          url: resUrl,
          fileName: resFileName,
          fileSize: finalSizeInBytes
        });
      }
      setEditingResId(null);
    } else {
      onAddResource({
        title: resTitle,
        category: resCategory,
        description: resDesc,
        url: resUrl,
        fileName: resFileName,
        fileSize: finalSizeInBytes
      });
    }

    // Reset
    setResTitle('');
    setResCategory('Core Textbooks');
    setResDesc('');
    setResUrl('');
    setResFileName('');
    setResFileSizeMB('420');
  };

  const handleStartEditResource = (r: EngineeringResource) => {
    setEditingResId(r.id);
    setResTitle(r.title);
    setResCategory(r.category);
    setResDesc(r.description || '');
    setResUrl(r.url || '');
    setResFileName(r.fileName || '');
    setResFileSizeMB((r.fileSize / (1024 * 1024)).toFixed(1));
  };

  const handleMoveResourceUp = (resourceId: string) => {
    const trueIndex = resources.findIndex(r => r.id === resourceId);
    if (trueIndex <= 0) return;
    const reordered = [...resources];
    const temp = reordered[trueIndex];
    reordered[trueIndex] = reordered[trueIndex - 1];
    reordered[trueIndex - 1] = temp;
    if (onReorderResources) {
      onReorderResources(reordered.map(r => r.id));
    }
  };

  const handleMoveResourceDown = (resourceId: string) => {
    const trueIndex = resources.findIndex(r => r.id === resourceId);
    if (trueIndex === -1 || trueIndex === resources.length - 1) return;
    const reordered = [...resources];
    const temp = reordered[trueIndex];
    reordered[trueIndex] = reordered[trueIndex + 1];
    reordered[trueIndex + 1] = temp;
    if (onReorderResources) {
      onReorderResources(reordered.map(r => r.id));
    }
  };

  const formatDuration = (sec: number) => {
    if (sec <= 0) return lang === 'ar' ? 'لا يوجد' : 'None';
    const hrs = Math.floor(sec / 3600);
    const mins = Math.floor((sec % 3600) / 60);
    const secs = sec % 60;

    if (lang === 'ar') {
      let res = '';
      if (hrs > 0) res += `${hrs} ساعة `;
      if (mins > 0) res += `${mins} دقيقة `;
      if (secs > 0 || res === '') res += `${secs} ثانية`;
      return res;
    } else {
      let res = '';
      if (hrs > 0) res += `${hrs}h `;
      if (mins > 0) res += `${mins}m `;
      if (secs > 0 || res === '') res += `${secs}s`;
      return res;
    }
  };

  const filteredLogs = logsList.filter(l => 
    l.userName.toLowerCase().includes(searchUserQuery.toLowerCase()) || 
    l.userEmail.toLowerCase().includes(searchUserQuery.toLowerCase())
  );

  return (
    <div className="space-y-6" dir={t.dir}>
      <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between border-b pb-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-800 flex items-center gap-2">
            <Activity className="h-6 w-6 text-teal-600 animate-pulse" />
            <span>{t.admin.title}</span>
          </h1>
          <p className="text-xs text-gray-500">{t.admin.desc}</p>
        </div>

        {/* Tab Controllers */}
        <div className="flex flex-wrap gap-1 bg-slate-100 p-1 rounded-xl">
          {[
            { id: 'tracking', label: t.admin.tabs.tracking, icon: Users },
            { id: 'auditlog', label: lang === 'ar' ? 'سجل تسجيل الدخول' : 'Login Activity Log', icon: History },
            { id: 'stats', label: lang === 'ar' ? 'تقرير الإحصائيات' : 'Statistics Report', icon: BarChart3 },
            { id: 'platforms', label: t.admin.tabs.platforms, icon: Monitor },
            { id: 'courses', label: lang === 'ar' ? 'الحقائب التدريبية' : 'Training Courses', icon: Award },
            { id: 'resources', label: lang === 'ar' ? 'المكتبة الهندسية' : 'Engineering Library', icon: BookOpen },
            { id: 'notifications', label: lang === 'ar' ? 'إدارة الإشعارات' : 'Manage Notifications', icon: Bell },
            { id: 'security', label: lang === 'ar' ? 'تغيير كلمة المرور' : 'Change Password', icon: Shield },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => {
                setActiveTab(tab.id as any);
                setSelectedUserLog(null);
                setPwdError('');
                setPwdSuccess('');
              }}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                activeTab === tab.id 
                  ? 'bg-white text-teal-800 shadow-xs border border-teal-100/50' 
                  : 'text-slate-600 hover:bg-slate-50'
              }`}
            >
              <tab.icon className="h-4 w-4" />
              <span>{tab.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* 1. VIEW A: USER TRACKING */}
      {activeTab === 'tracking' && (
        <div className="grid gap-6 lg:grid-cols-3 text-right">
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-800 flex items-center gap-1.5 font-sans">
                <Users className="h-5 w-5 text-gray-405" />
                <span>{t.admin.usersTitle} ({filteredLogs.length})</span>
              </h3>
              <button 
                onClick={fetchLogs} 
                className="p-1.5 border hover:bg-slate-50 rounded-lg transition cursor-pointer"
                title="Refresh Logs Data"
              >
                <RefreshCw className="h-4 w-4 text-slate-650" />
              </button>
            </div>

            <div className="relative">
              <input
                type="text"
                placeholder={t.admin.searchUser}
                value={searchUserQuery}
                onChange={(e) => setSearchUserQuery(e.target.value)}
                className="w-full rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-xs outline-none focus:border-teal-500 text-right"
              />
            </div>

            <div className="overflow-x-auto rounded-2xl border border-slate-150 bg-white shadow-xs">
              <table className="w-full text-right text-xs">
                <thead>
                  <tr className="bg-slate-50 border-b text-gray-500 font-bold">
                    <th className="p-4">{t.admin.table.name}</th>
                    <th className="p-4">{t.admin.table.email}</th>
                    <th className="p-4">{t.admin.table.role}</th>
                    <th className="p-4 text-center">{t.admin.table.clicks}</th>
                    <th className="p-4 text-center">{t.admin.table.duration}</th>
                    <th className="p-4"></th>
                  </tr>
                </thead>
                <tbody className="divide-y text-slate-700">
                  {isLoading ? (
                    <tr>
                      <td colSpan={6} className="p-8 text-center text-gray-400">
                        <RefreshCw className="h-5 w-5 animate-spin mx-auto text-teal-600 mb-2" />
                        <span>{t.admin.loading}</span>
                      </td>
                    </tr>
                  ) : filteredLogs.length > 0 ? (
                    filteredLogs.map((log) => (
                      <tr 
                        key={log.userId} 
                        className={`hover:bg-slate-50/50 transition ${selectedUserLog?.userId === log.userId ? 'bg-teal-50/45' : ''}`}
                      >
                        <td className="p-4 font-bold">{log.userName}</td>
                        <td className="p-4 font-mono text-gray-500 select-all">{log.userEmail}</td>
                        <td className="p-4">
                          <span className={`rounded-md px-2 py-0.5 text-[9px] font-bold ${
                            log.role === 'admin' ? 'bg-red-50 text-red-700' : 'bg-cyan-50 text-cyan-850'
                          }`}>
                            {log.role === 'admin' ? t.adminRole : t.studentRole}
                          </span>
                        </td>
                        <td className="p-4 text-center font-mono font-medium">{log.dailyUsageCount}</td>
                        <td className="p-4 text-center font-mono font-medium text-emerald-850">
                          {Math.round(log.totalActiveTimeSeconds / 60)} {lang === 'ar' ? 'دقيقة' : 'mins'}
                        </td>
                        <td className="p-4 text-left">
                          <button
                            onClick={() => setSelectedUserLog(log)}
                            className="inline-flex items-center gap-1 rounded-lg bg-teal-50 hover:bg-teal-100 px-2.5 py-1 text-[11px] text-teal-800 font-bold transition cursor-pointer"
                          >
                            <Eye className="h-3.5 w-3.5" />
                            <span>{t.admin.table.btnDetail}</span>
                          </button>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={6} className="p-8 text-center text-gray-400">No members match criteria.</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          <div className="space-y-6">
            <h3 className="text-sm font-bold text-slate-800 flex items-center gap-1.5">
              <Clock className="h-5 w-5 text-gray-450" />
              <span>{t.admin.inspectTitle}</span>
            </h3>

            {selectedUserLog ? (
              <motion.div
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                className="rounded-2xl border border-slate-100 bg-white p-5 space-y-6 shadow-sm text-right"
              >
                <div className="border-b pb-4 space-y-2">
                  <h4 className="text-md font-black text-slate-850">{selectedUserLog.userName}</h4>
                  <p className="text-xs text-gray-400 font-mono select-all leading-none">{selectedUserLog.userEmail}</p>
                  <p className="text-[10px] text-gray-500 pt-1 flex items-center gap-1 justify-end">
                    <Calendar className="h-3 w-3" />
                    <span>{t.admin.individual.registered} {new Date(selectedUserLog.registrationDate).toLocaleDateString(lang === 'ar' ? 'ar-IQ' : 'en-US')}</span>
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="p-3 bg-slate-50 rounded-xl border text-right">
                    <span className="text-[10px] text-gray-400">{t.admin.individual.clicksSum}</span>
                    <div className="font-mono text-lg font-black text-slate-700">{selectedUserLog.dailyUsageCount}</div>
                  </div>
                  <div className="p-3 bg-emerald-50 border-emerald-100 rounded-xl border text-right">
                    <span className="text-[10px] text-emerald-600">{t.admin.individual.timeSum}</span>
                    <div className="font-mono text-xs font-black text-emerald-800 leading-tight mt-1">
                      {formatDuration(selectedUserLog.totalActiveTimeSeconds)}
                    </div>
                  </div>
                </div>

                <div className="space-y-3">
                  <h5 className="text-xs font-bold text-slate-700 border-b pb-1">{t.admin.individual.staysTitle}</h5>
                  {Object.keys(selectedUserLog.platformStays).length > 0 ? (
                    <div className="space-y-2.5">
                      {Object.values(selectedUserLog.platformStays).map((pStay: any) => (
                        <div key={pStay.platformId} className="space-y-1">
                          <div className="flex justify-between text-xs font-semibold text-slate-850">
                            <span>{pStay.platformName}</span>
                            <span className="font-mono text-[10px] text-emerald-700 font-bold">{formatDuration(pStay.durationSeconds)}</span>
                          </div>
                          <div className="flex justify-between text-[10px] text-gray-450">
                            <span>{t.admin.individual.clicksCount}</span>
                            <span className="font-mono font-bold text-slate-650">{pStay.entriesCount}</span>
                          </div>
                          <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
                            <div 
                              className="h-full bg-teal-600" 
                              style={{ width: `${Math.min(100, (pStay.durationSeconds / (selectedUserLog.totalActiveTimeSeconds || 1)) * 100)}%` }}
                            />
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-[10px] text-gray-400 font-light text-center py-4 bg-slate-50/50 rounded-xl border">
                      {t.admin.individual.noStays}
                    </p>
                  )}
                </div>
              </motion.div>
            ) : (
              <div className="rounded-2xl border border-dashed text-center p-8 text-gray-400 text-xs font-light space-y-2">
                <Users className="h-10 w-10 mx-auto opacity-50 stroke-1" />
                <p>{t.admin.inspectSub}</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* 1.5 VIEW: LOGIN / ENTRY ACTIVITY AUDIT LOG */}
      {activeTab === 'auditlog' && (
        <div className="space-y-4 text-right">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-800 flex items-center gap-1.5 font-sans">
              <LogIn className="h-5 w-5 text-gray-405" />
              <span>{lang === 'ar' ? `سجل الدخول والنشاط (${auditLogs.length})` : `Login & Activity Log (${auditLogs.length})`}</span>
            </h3>
            <button
              onClick={fetchAuditLogs}
              className="p-1.5 border hover:bg-slate-50 rounded-lg transition cursor-pointer"
              title="Refresh Audit Log"
            >
              <RefreshCw className="h-4 w-4 text-slate-650" />
            </button>
          </div>

          <div className="overflow-x-auto rounded-2xl border border-slate-150 bg-white shadow-xs">
            <table className="w-full text-right text-xs">
              <thead>
                <tr className="bg-slate-50 border-b text-gray-500 font-bold">
                  <th className="p-4">{lang === 'ar' ? 'الاسم' : 'Name'}</th>
                  <th className="p-4">{lang === 'ar' ? 'البريد الإلكتروني' : 'Email'}</th>
                  <th className="p-4">{lang === 'ar' ? 'الحدث' : 'Event'}</th>
                  <th className="p-4">{lang === 'ar' ? 'التفاصيل' : 'Details'}</th>
                  <th className="p-4">{lang === 'ar' ? 'الوقت' : 'Time'}</th>
                  <th className="p-4">{lang === 'ar' ? 'عنوان IP' : 'IP Address'}</th>
                </tr>
              </thead>
              <tbody className="divide-y text-slate-700">
                {isLoading ? (
                  <tr>
                    <td colSpan={6} className="p-8 text-center text-gray-400">
                      <RefreshCw className="h-5 w-5 animate-spin mx-auto text-teal-600 mb-2" />
                      <span>{t.admin.loading}</span>
                    </td>
                  </tr>
                ) : auditLogs.length > 0 ? (
                  auditLogs.map((log: any) => {
                    const eventLabels: Record<string, { ar: string; en: string; color: string }> = {
                      REGISTRATION: { ar: 'تسجيل حساب جديد', en: 'New registration', color: 'bg-emerald-50 text-emerald-700' },
                      LOGIN: { ar: 'تسجيل دخول', en: 'Login', color: 'bg-cyan-50 text-cyan-800' },
                      LOGIN_GOOGLE: { ar: 'دخول عبر Google', en: 'Google login', color: 'bg-blue-50 text-blue-700' },
                      CREDENTIALS_CHANGED: { ar: 'تغيير كلمة المرور', en: 'Password changed', color: 'bg-amber-50 text-amber-800' },
                      '2FA_ACTIVATE': { ar: 'تفعيل التحقق الثنائي', en: '2FA enabled', color: 'bg-purple-50 text-purple-700' },
                    };
                    const meta = eventLabels[log.action] || { ar: log.action, en: log.action, color: 'bg-slate-50 text-slate-600' };
                    return (
                      <tr key={log.id} className="hover:bg-slate-50/50 transition">
                        <td className="p-4 font-bold">{log.userName}</td>
                        <td className="p-4 font-mono text-gray-500 select-all">{log.userEmail}</td>
                        <td className="p-4">
                          <span className={`rounded-md px-2 py-0.5 text-[9px] font-bold ${meta.color}`}>
                            {lang === 'ar' ? meta.ar : meta.en}
                          </span>
                        </td>
                        <td className="p-4 text-[11px] text-gray-500 max-w-[220px]">{log.details}</td>
                        <td className="p-4 font-mono text-[10px] text-gray-500 whitespace-nowrap">
                          {new Date(log.timestamp).toLocaleString(lang === 'ar' ? 'ar-IQ' : 'en-US')}
                        </td>
                        <td className="p-4 font-mono text-[10px] text-gray-400">{log.ipAddress}</td>
                      </tr>
                    );
                  })
                ) : (
                  <tr>
                    <td colSpan={6} className="p-8 text-center text-gray-400">
                      {lang === 'ar' ? 'لا يوجد نشاط مسجل حتى الآن.' : 'No activity recorded yet.'}
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* STATISTICS REPORT — screenshot/export-ready summary for external sharing */}
      {activeTab === 'stats' && (
        <div className="space-y-4 text-right">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <h3 className="text-sm font-bold text-slate-800 flex items-center gap-1.5 font-sans">
              <BarChart3 className="h-5 w-5 text-gray-405" />
              <span>{lang === 'ar' ? 'تقرير إحصائيات المنصة' : 'Platform Statistics Report'}</span>
            </h3>
            <div className="flex items-center gap-2">
              <button
                onClick={fetchStats}
                className="p-1.5 border hover:bg-slate-50 rounded-lg transition cursor-pointer"
                title={lang === 'ar' ? 'تحديث' : 'Refresh'}
              >
                <RefreshCw className="h-4 w-4 text-slate-650" />
              </button>
              <button
                onClick={handleExportStatsPdf}
                disabled={isExportingPdf || !statsData}
                className="flex items-center gap-1.5 rounded-lg bg-teal-600 hover:bg-teal-700 disabled:bg-slate-300 px-3.5 py-1.5 text-xs font-bold text-white transition cursor-pointer"
              >
                <Download className="h-3.5 w-3.5" />
                <span>{isExportingPdf ? (lang === 'ar' ? 'جارِ التصدير...' : 'Exporting...') : (lang === 'ar' ? 'تصدير PDF' : 'Export PDF')}</span>
              </button>
            </div>
          </div>

          {statsLoading && !statsData ? (
            <div className="p-8 text-center text-gray-400">
              <RefreshCw className="h-5 w-5 animate-spin mx-auto text-teal-600 mb-2" />
              <span>{t.admin.loading}</span>
            </div>
          ) : statsData ? (
            <div ref={statsReportRef} className="bg-white rounded-2xl border border-slate-150 shadow-xs p-6 space-y-6">
              <div className="text-center space-y-1 pb-2 border-b border-slate-100">
                <h4 className="text-lg font-black text-teal-800">
                  {lang === 'ar' ? 'تقرير إحصائيات منصة الهيئة العامة للكيميائيين - البصرة' : 'GCE Basra Platform Statistics Report'}
                </h4>
                <p className="text-[10px] text-gray-400 font-mono">
                  {lang === 'ar' ? 'تاريخ إعداد التقرير: ' : 'Report generated: '}
                  {new Date(statsData.generatedAt).toLocaleString(lang === 'ar' ? 'ar-IQ' : 'en-US')}
                </p>
              </div>

              {/* Summary cards */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {[
                  { label: lang === 'ar' ? 'إجمالي المستخدمين' : 'Total Users', value: statsData.totalUsers, icon: Users, color: 'text-teal-700 bg-teal-50' },
                  { label: lang === 'ar' ? 'الطلاب/الأعضاء' : 'Students/Members', value: statsData.totalStudents, icon: Award, color: 'text-blue-700 bg-blue-50' },
                  { label: lang === 'ar' ? 'نشطون اليوم' : 'Active Today', value: statsData.activeToday, icon: Activity, color: 'text-emerald-700 bg-emerald-50' },
                  { label: lang === 'ar' ? 'نشطون هذا الأسبوع' : 'Active This Week', value: statsData.activeThisWeek, icon: Clock, color: 'text-amber-700 bg-amber-50' },
                  { label: lang === 'ar' ? 'إجمالي التسجيلات' : 'Total Registrations', value: statsData.totalRegistrations, icon: Plus, color: 'text-purple-700 bg-purple-50' },
                  { label: lang === 'ar' ? 'إجمالي عمليات الدخول' : 'Total Logins', value: statsData.totalLogins, icon: LogIn, color: 'text-cyan-700 bg-cyan-50' },
                ].map((card, i) => (
                  <div key={i} className={`rounded-xl p-4 ${card.color} flex flex-col items-center gap-1.5`}>
                    <card.icon className="h-4 w-4" />
                    <span className="text-xl font-black">{card.value}</span>
                    <span className="text-[10px] font-bold text-center opacity-80">{card.label}</span>
                  </div>
                ))}
              </div>

              {/* 30-day activity chart */}
              <div className="rounded-xl border border-slate-100 p-4">
                <h5 className="text-xs font-bold text-slate-700 mb-3">
                  {lang === 'ar' ? 'النشاط خلال آخر 30 يوماً' : 'Activity over the last 30 days'}
                </h5>
                <ResponsiveContainer width="100%" height={220}>
                  <LineChart data={statsData.dailySeries}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#eee" />
                    <XAxis dataKey="date" tick={{ fontSize: 9 }} tickFormatter={(d) => d.slice(5)} />
                    <YAxis tick={{ fontSize: 9 }} allowDecimals={false} />
                    <Tooltip />
                    <Legend wrapperStyle={{ fontSize: 10 }} />
                    <Line type="monotone" dataKey="registrations" name={lang === 'ar' ? 'تسجيلات جديدة' : 'New registrations'} stroke="#0d9488" strokeWidth={2} dot={false} />
                    <Line type="monotone" dataKey="logins" name={lang === 'ar' ? 'عمليات دخول' : 'Logins'} stroke="#2563eb" strokeWidth={2} dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              </div>

              {/* Breakdown by academic stage */}
              {statsData.byAcademicYear && Object.keys(statsData.byAcademicYear).length > 0 && (
                <div className="rounded-xl border border-slate-100 p-4">
                  <h5 className="text-xs font-bold text-slate-700 mb-3">
                    {lang === 'ar' ? 'توزيع المستخدمين حسب المرحلة' : 'Users by academic stage'}
                  </h5>
                  <ResponsiveContainer width="100%" height={Math.max(160, Object.keys(statsData.byAcademicYear).length * 34)}>
                    <BarChart
                      layout="vertical"
                      data={Object.entries(statsData.byAcademicYear).map(([name, value]) => ({ name, value }))}
                      margin={{ left: 10, right: 20 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" stroke="#eee" />
                      <XAxis type="number" tick={{ fontSize: 9 }} allowDecimals={false} />
                      <YAxis type="category" dataKey="name" tick={{ fontSize: 9 }} width={160} />
                      <Tooltip />
                      <Bar dataKey="value" fill="#0d9488" radius={[0, 6, 6, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              )}
            </div>
          ) : (
            <div className="p-8 text-center text-gray-400 text-xs">
              {lang === 'ar' ? 'تعذر تحميل بيانات الإحصائيات.' : 'Could not load statistics.'}
            </div>
          )}
        </div>
      )}

      {/* 2. VIEW B: MANAGE DIGITAL PLATFORMS */}
      {activeTab === 'platforms' && (
        <div className="grid gap-8 md:grid-cols-3 text-right">
          <div className="rounded-2xl border border-slate-100 bg-white p-5 space-y-4 shadow-xs h-fit">
            <h3 className="text-sm font-black text-slate-805">
              {editingPlatId ? t.admin.managePlat.editTitle : t.admin.managePlat.addTitle}
            </h3>
            <p className="text-[11px] text-gray-450 font-light">
              {t.admin.managePlat.formDesc}
            </p>

            <form onSubmit={handleAddPlatSubmit} className="space-y-3.5">
              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-650 block text-right">عنوان المنصة / المحاكي</label>
                <input
                  type="text"
                  required
                  value={platName}
                  onChange={(e) => setPlatName(e.target.value)}
                  placeholder="مثال: مختبر قياس التراكيز العضوية UV"
                  className="w-full rounded-xl border border-slate-201 bg-slate-50 px-3 py-2 text-xs focus:bg-white outline-none focus:border-teal-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-650 block text-right">رابط المحاكي أو المنصة</label>
                <input
                  type="url"
                  required
                  value={platUrl}
                  onChange={(e) => setPlatUrl(e.target.value)}
                  placeholder="https://..."
                  className="w-full rounded-xl border border-slate-201 bg-slate-50 px-3 py-2 text-xs focus:bg-white outline-none focus:border-teal-500 font-mono text-left"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-650 block text-right">رابط الصورة (اختياري)</label>
                <input
                  type="text"
                  value={platImg}
                  onChange={(e) => setPlatImg(e.target.value)}
                  placeholder="https://images.unsplash.com/..."
                  className="w-full rounded-xl border border-slate-201 bg-slate-50 px-3 py-2 text-[11px] focus:bg-white outline-none focus:border-teal-500 font-mono text-left"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-650 block text-right">شرح ووصف المنصة</label>
                <textarea
                  value={platDesc}
                  onChange={(e) => setPlatDesc(e.target.value)}
                  placeholder="شرح موجز لأهمية هذا المحاكي للمهندس الكيميائي..."
                  className="w-full h-24 rounded-xl border border-slate-201 bg-slate-50 p-3 text-xs focus:bg-white outline-none focus:border-teal-500 resize-none"
                />
              </div>

              <button
                type="submit"
                className="w-full rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs py-2.5 transition cursor-pointer"
              >
                {editingPlatId ? 'حفظ وبث التحديث' : 'إضافة وبث منصة رقمية جديدة'}
              </button>
              {editingPlatId && (
                <button
                  type="button"
                  onClick={() => {
                    setEditingPlatId(null);
                    setPlatName('');
                    setPlatUrl('');
                    setPlatDesc('');
                    setPlatImg('');
                  }}
                  className="w-full rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-600 text-xs py-2 transition cursor-pointer"
                >
                  إلغاء التعديل
                </button>
              )}
            </form>
          </div>

          <div className="md:col-span-2 space-y-4">
            <h3 className="text-sm font-bold text-slate-800">قائمة المنصات والمحاكيات النشطة ({platforms.length})</h3>
            
            <div className="space-y-3">
              {platforms.map((plat) => (
                <div 
                  key={plat.id}
                  className="rounded-2xl border border-slate-100 bg-white p-4 shadow-xs flex items-center justify-between gap-4"
                >
                  <div className="flex gap-1 shrink-0 items-center">
                    <button
                      onClick={() => handleMovePlatformUp(plat.id)}
                      className="p-1 rounded-lg bg-slate-50 text-slate-500 hover:bg-slate-100 transition cursor-pointer"
                      title="Move Up"
                    >
                      <ArrowUp className="h-3.5 w-3.5" />
                    </button>
                    <button
                      onClick={() => handleMovePlatformDown(plat.id)}
                      className="p-1 rounded-lg bg-slate-50 text-slate-500 hover:bg-slate-100 transition cursor-pointer"
                      title="Move Down"
                    >
                      <ArrowDown className="h-3.5 w-3.5" />
                    </button>
                    <button
                      onClick={() => handleStartEditPlatform(plat)}
                      className="p-1.5 rounded-lg bg-teal-50 text-teal-805 hover:bg-teal-100 transition cursor-pointer"
                      title="تعديل المنصة"
                    >
                      <Edit className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => onDeletePlatform(plat.id)}
                      className="p-1.5 rounded-lg bg-red-50 text-red-500 hover:bg-red-100 transition cursor-pointer"
                      title="حذف المنصة"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="space-y-0.5 text-right">
                      <h4 className="text-xs font-bold text-slate-850 leading-tight">{plat.name}</h4>
                      <p className="text-[9px] text-gray-400 font-mono line-clamp-1">{plat.url}</p>
                      <p className="text-[11px] text-gray-500 line-clamp-2 max-w-sm md:max-w-md font-light">{plat.description}</p>
                    </div>
                    {plat.image && (
                      <img 
                        src={plat.image} 
                        alt={plat.name} 
                        className="h-12 w-16 object-cover rounded-lg bg-slate-100 border shrink-0"
                      />
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 3. VIEW C: MANAGE COURSES */}
      {activeTab === 'courses' && (
        <div className="grid gap-8 md:grid-cols-3 text-right">
          <div className="rounded-2xl border border-slate-100 bg-white p-5 space-y-4 shadow-xs h-fit">
            <h3 className="text-sm font-black text-slate-805">
              {editingCourseId ? 'تعديل الحقيبة التدريبية' : 'إضافة حقيبة تدريبية جديدة'}
            </h3>
            <p className="text-[11px] text-gray-450 font-light">
              قم بصياغة البيانات الفنية للحقيبة التدريبية وسيتم توليد تنبيه رسمي للمهندسين تلقائياً فور الحفظ.
            </p>

            <form onSubmit={handleAddCourseSubmit} className="space-y-3.5">
              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-650 block text-right">عنوان الحقيبة التدريبية / الكورس</label>
                <input
                  type="text"
                  required
                  value={courseTitle}
                  onChange={(e) => setCourseTitle(e.target.value)}
                  placeholder="مثال: الحقيبة المتكاملة لإنتاج المنظفات الكيميائية"
                  className="w-full rounded-xl border border-slate-201 bg-slate-50 px-3 py-2 text-xs focus:bg-white outline-none focus:border-teal-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-650 block text-right">رابط درايف للحقيبة أو التسجيل</label>
                <input
                  type="url"
                  required
                  value={courseUrl}
                  onChange={(e) => setCourseUrl(e.target.value)}
                  placeholder="https://drive.google.com/..."
                  className="w-full rounded-xl border border-slate-201 bg-slate-50 px-3 py-2 text-xs focus:bg-white outline-none focus:border-teal-500 font-mono text-left"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-650 block text-right">المحاضر أو الجهة العلمية</label>
                <input
                  type="text"
                  value={courseInstructor}
                  onChange={(e) => setCourseInstructor(e.target.value)}
                  placeholder="مثال: لجنة التدريب بالهيئة العامة بالبصرة"
                  className="w-full rounded-xl border border-slate-201 bg-slate-50 px-3 py-2 text-xs focus:bg-white outline-none focus:border-teal-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-650 block text-right">شرح تفصيلي للمنهج واللقاءات</label>
                <textarea
                  value={courseDesc}
                  onChange={(e) => setCourseDesc(e.target.value)}
                  placeholder="تفاصيل محاور اللقاء التدريبي الفني والمحاكاة المطلوبة..."
                  className="w-full h-24 rounded-xl border border-slate-201 bg-slate-50 p-3 text-xs focus:bg-white outline-none focus:border-teal-500 resize-none"
                />
              </div>

              <button
                type="submit"
                className="w-full rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs py-2.5 transition cursor-pointer"
              >
                {editingCourseId ? 'حفظ وبث التحديث للحقيبة' : 'طرح ونشر الحقيبة فورا للكل'}
              </button>
              {editingCourseId && (
                <button
                  type="button"
                  onClick={() => {
                    setEditingCourseId(null);
                    setCourseTitle('');
                    setCourseUrl('');
                    setCourseDesc('');
                    setCourseInstructor('');
                  }}
                  className="w-full rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-600 text-xs py-2 transition cursor-pointer"
                >
                  إلغاء التعديل
                </button>
              )}
            </form>
          </div>

          <div className="md:col-span-2 space-y-4">
            <h3 className="text-sm font-bold text-slate-800">الحقائب والمناهج المتاحة للدراسة ({courses.length})</h3>
            
            <div className="space-y-3">
              {courses.map((course) => (
                <div 
                  key={course.id}
                  className="rounded-2xl border border-slate-100 bg-white p-4 shadow-xs flex items-center justify-between gap-4"
                >
                  <div className="flex gap-1 shrink-0 items-center">
                    <button
                      onClick={() => handleMoveCourseUp(course.id)}
                      className="p-1 rounded-lg bg-slate-50 text-slate-500 hover:bg-slate-100 transition cursor-pointer"
                      title="Move Up"
                    >
                      <ArrowUp className="h-3.5 w-3.5" />
                    </button>
                    <button
                      onClick={() => handleMoveCourseDown(course.id)}
                      className="p-1 rounded-lg bg-slate-50 text-slate-500 hover:bg-slate-100 transition cursor-pointer"
                      title="Move Down"
                    >
                      <ArrowDown className="h-3.5 w-3.5" />
                    </button>
                    <button
                      onClick={() => handleStartEditCourse(course)}
                      className="p-1.5 rounded-lg bg-teal-50 text-teal-805 hover:bg-teal-100 transition cursor-pointer"
                      title="تعديل الحقيبة"
                    >
                      <Edit className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => onDeleteCourse(course.id)}
                      className="p-1.5 rounded-lg bg-red-50 text-red-500 hover:bg-red-100 transition cursor-pointer"
                      title="حذف الحقيبة"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="space-y-0.5 text-right flex-1">
                      <div className="flex items-center gap-2 justify-end">
                        <span className="text-[10px] bg-slate-100 text-slate-600 rounded px-1.5 font-bold">
                          م. {course.instructor || 'لجنة التدريب'}
                        </span>
                        <h4 className="text-xs font-bold text-slate-850">{course.title}</h4>
                      </div>
                      <p className="text-[9px] text-gray-400 font-mono line-clamp-1">{course.url}</p>
                      <p className="text-[11px] text-gray-500 line-clamp-2 max-w-sm font-light mt-1">{course.description}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 4. VIEW D: MANAGE RESOURCES */}
      {activeTab === 'resources' && (
        <div className="grid gap-8 md:grid-cols-3 text-right">
          <div className="rounded-2xl border border-slate-100 bg-white p-5 space-y-4 shadow-xs h-fit">
            <h3 className="text-sm font-black text-slate-805">
              {editingResId ? 'تعديل المصدر والملخص' : 'رفع وإضافة مصدر للمكتبة'}
            </h3>
            <p className="text-[11px] text-gray-450 font-light">
              قم بإدراج مراجع علمية أو ملفات لمهندسي البصرة (يدعم إدراج ملفات تزيد عن 400 ميجابايت).
            </p>

            <form onSubmit={handleAddResourceSubmit} className="space-y-3.5">
              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-650 block text-right">عنوان المستند / المرجع</label>
                <input
                  type="text"
                  required
                  value={resTitle}
                  onChange={(e) => setResTitle(e.target.value)}
                  placeholder="مثال: معجم الكيمياء الصناعية للبتروكيماويات"
                  className="w-full rounded-xl border border-slate-201 bg-slate-50 px-3 py-2 text-xs focus:bg-white outline-none focus:border-teal-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-650 block text-right">تصنيف المصدر</label>
                <select
                  value={resCategory}
                  onChange={(e) => setResCategory(e.target.value)}
                  className="w-full rounded-xl border border-slate-201 bg-slate-50 px-3 py-2 text-xs focus:bg-white outline-none focus:border-teal-500 text-right"
                >
                  <option value="كتب عامة">كتب كيميائية عامة</option>
                  <option value="تصفية الغاز">تقنيات تصفية ومعالجة الغاز</option>
                  <option value="مختبرات">تقارير وفحوصات مختبرية</option>
                  <option value="أبحاث">أبحاث الكيمياء والبيئة بالبصرة</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-650 block text-right">اسم الملف الفعلي</label>
                <input
                  type="text"
                  required
                  value={resFileName}
                  onChange={(e) => setResFileName(e.target.value)}
                  placeholder="مثال: Gas_Treating_Guide_2026.pdf"
                  className="w-full rounded-xl border border-slate-201 bg-slate-50 px-3 py-2 text-xs focus:bg-white outline-none focus:border-teal-500 font-mono text-left"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-650 block text-right">رابط التنزيل المباشر</label>
                <input
                  type="url"
                  required
                  value={resUrl}
                  onChange={(e) => setResUrl(e.target.value)}
                  placeholder="https://..."
                  className="w-full rounded-xl border border-slate-201 bg-slate-50 px-3 py-2 text-xs focus:bg-white outline-none focus:border-teal-500 font-mono text-left"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-650 block text-right">حجم المستند التقريبي (بالميجابايت)</label>
                <input
                  type="number"
                  step="0.1"
                  required
                  value={resFileSizeMB}
                  onChange={(e) => setResFileSizeMB(e.target.value)}
                  placeholder="420"
                  className="w-full rounded-xl border border-slate-201 bg-slate-50 px-3 py-2 text-xs focus:bg-white outline-none focus:border-teal-500 font-mono text-left"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-650 block text-right">وصف إضافي للملف</label>
                <textarea
                  value={resDesc}
                  onChange={(e) => setResDesc(e.target.value)}
                  placeholder="أهم فصول الكتاب أو الملخص ومستوى الفائدة العملية منه..."
                  className="w-full h-20 rounded-xl border border-slate-201 bg-slate-50 p-3 text-xs focus:bg-white outline-none focus:border-teal-500 resize-none"
                />
              </div>

              <button
                type="submit"
                className="w-full rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs py-2.5 transition cursor-pointer"
              >
                {editingResId ? 'حفظ وبث التحديث الفني للمصدر' : 'نشر وتوفير المرجع فورا في المكتبة'}
              </button>
              {editingResId && (
                <button
                  type="button"
                  onClick={() => {
                    setEditingResId(null);
                    setResTitle('');
                    setResCategory('Core Textbooks');
                    setResDesc('');
                    setResUrl('');
                    setResFileName('');
                    setResFileSizeMB('420');
                  }}
                  className="w-full rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-600 text-xs py-2 transition cursor-pointer"
                >
                  إلغاء التعديل
                </button>
              )}
            </form>
          </div>

          <div className="md:col-span-2 space-y-4">
            <h3 className="text-sm font-bold text-slate-800">ملفات ومصادر المكتبة الهندسية النشطة ({resources.length})</h3>
            
            <div className="space-y-3">
              {resources.map((res) => (
                <div 
                  key={res.id}
                  className="rounded-2xl border border-slate-100 bg-white p-4 shadow-xs flex items-center justify-between gap-4"
                >
                  <div className="flex gap-1 shrink-0 items-center">
                    <button
                      onClick={() => handleMoveResourceUp(res.id)}
                      className="p-1 rounded-lg bg-slate-50 text-slate-500 hover:bg-slate-100 transition cursor-pointer"
                      title="Move Up"
                    >
                      <ArrowUp className="h-3.5 w-3.5" />
                    </button>
                    <button
                      onClick={() => handleMoveResourceDown(res.id)}
                      className="p-1 rounded-lg bg-slate-50 text-slate-500 hover:bg-slate-100 transition cursor-pointer"
                      title="Move Down"
                    >
                      <ArrowDown className="h-3.5 w-3.5" />
                    </button>
                    <button
                      onClick={() => handleStartEditResource(res)}
                      className="p-1.5 rounded-lg bg-teal-50 text-teal-805 hover:bg-teal-100 transition cursor-pointer"
                      title="تعديل المصدر"
                    >
                      <Edit className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => onDeleteResource(res.id)}
                      className="p-1.5 rounded-lg bg-red-50 text-red-500 hover:bg-red-100 transition cursor-pointer"
                      title="حذف المصدر"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="space-y-0.5 text-right flex-1">
                      <div className="flex items-center gap-2 justify-end">
                        <span className="text-[9px] bg-emerald-50 text-emerald-850 rounded px-1.5 font-bold">
                          {(res.fileSize / (1024 * 1024)).toFixed(1)} MB
                        </span>
                        <span className="text-[10px] bg-slate-100 text-slate-600 rounded px-1.5 font-bold">
                          {res.category}
                        </span>
                        <h4 className="text-xs font-bold text-slate-855">{res.title}</h4>
                      </div>
                      <p className="text-[9px] text-gray-400 font-mono line-clamp-1">{res.fileName}</p>
                      <p className="text-[11px] text-gray-500 line-clamp-2 max-w-sm font-light mt-1">{res.description}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 5. VIEW E: SECURITY & PASSWORD CREDENTIALS */}
      {activeTab === 'security' && (
        <div className="max-w-md mx-auto rounded-3xl border border-slate-150 bg-white p-6 md:p-8 shadow-md text-right">
          <div className="flex flex-col items-center text-center space-y-3 mb-6">
            <div className="bg-amber-100 p-3 rounded-full">
              <Shield className="h-6 w-6 text-amber-700 animate-bounce" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-800">
                {lang === 'ar' ? 'تغيير كلمة مرور الإدارة' : 'Change Administrator Password'}
              </h3>
              <p className="text-xs text-gray-500 mt-1">
                {lang === 'ar' 
                  ? 'قم بتأمين حساب المشرف الخاص بك عن طريق تعيين كلمة مرور جديدة وقوية للمستقبل.' 
                  : 'Secure your supervisor account by setting a strong, fresh administrator password.'}
              </p>
            </div>
          </div>

          {pwdError && (
            <div className="mb-4 p-3 rounded-xl bg-red-50 border border-red-200 text-red-600 text-xs font-bold text-center">
              {pwdError}
            </div>
          )}

          {pwdSuccess && (
            <div className="mb-4 p-3 rounded-xl bg-teal-50 border border-teal-200 text-teal-700 text-xs font-bold text-center">
              {pwdSuccess}
            </div>
          )}

          <form onSubmit={async (e) => {
            e.preventDefault();
            setPwdError('');
            setPwdSuccess('');

            if (!currentPassword || !newPassword || !confirmPassword) {
              setPwdError(lang === 'ar' ? 'الرجاء تعبئة جميع الحقول المطلوبة للتغيير.' : 'Please fill all required password fields.');
              return;
            }

            if (newPassword !== confirmPassword) {
              setPwdError(lang === 'ar' ? 'كلمات المرور الجديدة غير متطابقة!' : 'New passwords do not match!');
              return;
            }

            if (!/^\d{4}$/.test(currentPassword) || !/^\d{4}$/.test(newPassword)) {
              setPwdError(lang === 'ar' ? 'يجب أن يكون الرمز (الحالي والجديد) 4 أرقام فقط، تماماً كرمز الدخول.' : 'Both current and new codes must be exactly 4 digits, same as your login PIN.');
              return;
            }

            setPwdLoading(true);
            try {
              // There is no backend anymore — the "password" here is really
              // your 4-digit login PIN, verified directly against Firebase Auth.
              if (!auth.currentUser || !currentUser?.email) {
                throw new Error(lang === 'ar' ? 'الجلسة غير متصلة بخدمة المصادقة، الرجاء تسجيل الخروج والدخول مجدداً.' : 'Session not linked to auth service — please sign out and back in.');
              }
              const oldCred = EmailAuthProvider.credential(currentUser.email, `pass-${currentPassword}-gce`);
              await reauthenticateWithCredential(auth.currentUser, oldCred);
              await updatePassword(auth.currentUser, `pass-${newPassword}-gce`);

              setPwdSuccess(lang === 'ar' ? 'تم تغيير رمز الدخول بنجاح! استخدم الرمز الجديد عند تسجيل الدخول المرة القادمة.' : 'PIN updated successfully! Use the new PIN for your future logins.');
              setCurrentPassword('');
              setNewPassword('');
              setConfirmPassword('');
            } catch (err: any) {
              const friendly = err?.code === 'auth/invalid-credential' || err?.code === 'auth/wrong-password'
                ? (lang === 'ar' ? 'الرمز الحالي غير صحيح.' : 'Current PIN is incorrect.')
                : (err.message || (lang === 'ar' ? 'فشل تعديل الرمز.' : 'Failed to change PIN.'));
              setPwdError(friendly);
            } finally {
              setPwdLoading(false);
            }
          }} className="space-y-4">
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700 block text-right">
                {lang === 'ar' ? 'كلمة المرور الحالية لبريد الإدارة:' : 'Current Admin Password:'}
              </label>
              <input
                type="password"
                required
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                placeholder="•••••"
                className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-2.5 text-xs focus:bg-white outline-none focus:border-teal-500 text-center font-mono"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700 block text-right">
                {lang === 'ar' ? 'كلمة المرور الجديدة المقترحة:' : 'New Supervisor Password:'}
              </label>
              <input
                type="password"
                required
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="•••••"
                className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-2.5 text-xs focus:bg-white outline-none focus:border-teal-500 text-center font-mono"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700 block text-right">
                {lang === 'ar' ? 'تأكيد كلمة المرور الجديدة:' : 'Confirm New Password:'}
              </label>
              <input
                type="password"
                required
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="•••••"
                className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-2.5 text-xs focus:bg-white outline-none focus:border-teal-500 text-center font-mono"
              />
            </div>

            <button
              type="submit"
              disabled={pwdLoading}
              className="w-full mt-2 rounded-xl bg-amber-600 hover:bg-amber-700 font-bold text-xs py-3 text-white transition hover:shadow-md cursor-pointer flex items-center justify-center gap-2"
            >
              {pwdLoading ? (
                <RefreshCw className="h-4 w-4 animate-spin" />
              ) : (
                <span>{lang === 'ar' ? 'حفظ وتثبيت كلمة المرور' : 'Save & Assert New Password'}</span>
              )}
            </button>
          </form>
        </div>
      )}

      {/* 6. VIEW F: NOTIFICATIONS CONTROL CENTER */}
      {activeTab === 'notifications' && (
        <div className="space-y-6 text-right">
          <div className="grid gap-6 lg:grid-cols-3">
            {/* Notification Creator Form */}
            <div className="lg:col-span-2 rounded-2xl border border-slate-150 bg-white p-6 shadow-xs space-y-5">
              <div className="flex items-center gap-2 border-b pb-3 mb-2 justify-end">
                <span className="text-sm font-black text-slate-800">صناعة وبث إشعار جديد للمنصة</span>
                <Bell className="h-5 w-5 text-teal-600 animate-bounce" />
              </div>

              <form onSubmit={(e) => { e.preventDefault(); setIsPreviewing(true); }} className="space-y-4">
                {/* Title */}
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 block">عنوان الإشعار (بالعربية)</label>
                  <input
                    type="text"
                    required
                    value={notifTitle}
                    onChange={(e) => setNotifTitle(e.target.value)}
                    placeholder="مثال: تحديث أوقات صيانة خوادم المحاكات الرقمية للنفط"
                    className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-2.5 text-xs focus:bg-white outline-none focus:ring-1 focus:ring-teal-500"
                  />
                </div>

                {/* Message Context */}
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 block">نص ومضمون الإشعار بالتفصيل</label>
                  <textarea
                    required
                    rows={4}
                    value={notifMessage}
                    onChange={(e) => setNotifMessage(e.target.value)}
                    placeholder="اكتب هنا التفاصيل الكاملة للإعلان الهام..."
                    className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-2.5 text-xs focus:bg-white outline-none focus:ring-1 focus:ring-teal-500 resize-none font-sans"
                  />
                </div>

                {/* Row: Type and Send Method */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Type Selector (تحديث / تنبيه / إعلان / صيانة) */}
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-700 block">نوع الإشعار وتصنيفه</label>
                    <div className="grid grid-cols-2 gap-2">
                      {[
                        { id: 'update', label: 'تحديث خوادم', icon: Award, color: 'hover:border-teal-500 border-slate-200 text-teal-600' },
                        { id: 'alert', label: 'تنبيه أمان', icon: Clock, color: 'hover:border-red-500 border-slate-200 text-red-600' },
                        { id: 'announcement', label: 'إعلان عام', icon: BookOpen, color: 'hover:border-sky-500 border-slate-200 text-sky-600' },
                        { id: 'maintenance', label: 'أعمال صيانة', icon: Wrench, color: 'hover:border-amber-500 border-slate-200 text-amber-600 font-bold' }
                      ].map((typeItem) => (
                        <button
                          key={typeItem.id}
                          type="button"
                          onClick={() => setNotifType(typeItem.id as any)}
                          className={`p-2.5 rounded-xl border text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
                            notifType === typeItem.id
                              ? 'border-slate-900 bg-slate-950 text-white shadow-xs'
                              : `bg-slate-50 ${typeItem.color}`
                          }`}
                        >
                          <typeItem.icon className="h-4 w-4 shrink-0" />
                          <span>{typeItem.label}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Send Method Selector */}
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-700 block">طريقة الإرسال والبث</label>
                    <div className="grid grid-cols-1 gap-2">
                      {[
                        { id: 'internal', label: 'إشعار داخلي في المنصة فقط (في قاعدة بيانتنا)', icon: Bell },
                        { id: 'email', label: 'إرسال بالبريد الإلكتروني فقط (Trigger Email)', icon: Mail },
                        { id: 'both', label: 'الكل (داخلي بالمنصة + بريد إلكتروني فوري)', icon: Send }
                      ].map((methodItem) => (
                        <button
                          key={methodItem.id}
                          type="button"
                          onClick={() => setNotifSendMethod(methodItem.id as any)}
                          className={`p-2.5 rounded-xl border text-xs font-bold transition flex items-center gap-2 justify-start cursor-pointer w-full text-right ${
                            notifSendMethod === methodItem.id
                              ? 'border-slate-900 bg-slate-950 text-white shadow-xs'
                              : 'border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-700'
                          }`}
                        >
                          <methodItem.icon className="h-4 w-4 text-teal-600" />
                          <span>{methodItem.label}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Target Audience Selector (الكل / مستهدفين محددين) */}
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 block">تحديد الفئة والمستخدمين المستهدفين</label>
                  <div className="flex gap-4">
                    <label className="flex items-center gap-2 cursor-pointer p-2 bg-slate-50 rounded-xl border w-full justify-between">
                      <span className="text-xs font-bold text-slate-800">بث لكافة المنتسبين عموماً (all)</span>
                      <input
                        type="radio"
                        name="targetAudience"
                        checked={notifTarget === 'all'}
                        onChange={() => { setNotifTarget('all'); setNotifSelectedUsers([]); }}
                        className="accent-teal-600 cursor-pointer h-4 w-4"
                      />
                    </label>

                    <label className="flex items-center gap-2 cursor-pointer p-2 bg-slate-50 rounded-xl border w-full justify-between">
                      <span className="text-xs font-bold text-slate-800">مستخدمين محددين بالـ ID أو البريد</span>
                      <input
                        type="radio"
                        name="targetAudience"
                        checked={notifTarget === 'specific'}
                        onChange={() => setNotifTarget('specific')}
                        className="accent-teal-600 cursor-pointer h-4 w-4"
                      />
                    </label>
                  </div>
                </div>

                {/* Send Buttons triggers */}
                <div className="pt-2 flex gap-3">
                  <button
                    type="submit"
                    className="flex-1 bg-slate-950 hover:bg-slate-900 text-white font-extrabold text-xs py-3.5 rounded-xl transition cursor-pointer flex items-center justify-center gap-2 shadow-xs"
                  >
                    <Eye className="h-4 w-4" />
                    <span>مراجعة ومعاينة الإشعار قبل الإرسال</span>
                  </button>
                </div>
              </form>
            </div>

            {/* Target users list selection side panel */}
            <div className="rounded-2xl border border-slate-150 bg-white p-5 shadow-xs space-y-4">
              <h3 className="text-xs font-black text-slate-800 border-b pb-2 flex items-center gap-1.5 justify-end">
                <span>تخصيص المستلمِين ({notifSelectedUsers.length} محددين)</span>
                <Users className="h-4.5 w-4.5 text-gray-400" />
              </h3>

              {notifTarget === 'all' ? (
                <div className="flex flex-col items-center justify-center text-center p-8 bg-slate-50 border border-dashed rounded-xl h-64 text-slate-400 border-slate-200">
                  <Send className="h-8 w-8 text-slate-300 mb-2" />
                  <p className="text-xs font-bold text-slate-600">بث عام نشط</p>
                  <p className="text-[10px] text-slate-400 font-light leading-normal max-w-[200px] mt-1">
                    الإشعار موجه لكافة المستخدمين المسجلين في المنصة تلقائياً ولن تحتاج لتحديد مستخدمين يدوياً.
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  <p className="text-[10.5px] text-teal-600 bg-teal-50 border border-teal-100 p-2.5 rounded-xl font-medium">
                    حدد المستخدمين المراد توجيه الإشعار لبريدهم وحسابهم الداخلي بالأسفل:
                  </p>
                  <div className="max-h-64 overflow-y-auto divide-y border rounded-xl divide-slate-150">
                    {logsList.map((usr) => {
                      const isChecked = notifSelectedUsers.includes(usr.userId);
                      return (
                        <div
                          key={usr.userId}
                          onClick={() => {
                            if (isChecked) {
                              setNotifSelectedUsers(notifSelectedUsers.filter(id => id !== usr.userId));
                            } else {
                              setNotifSelectedUsers([...notifSelectedUsers, usr.userId]);
                            }
                          }}
                          className={`p-2.5 hover:bg-slate-50 transition flex items-center gap-2 justify-between cursor-pointer ${
                            isChecked ? 'bg-teal-500/5' : ''
                          }`}
                        >
                          <div className="flex items-center gap-2 justify-end text-right">
                            {isChecked ? (
                              <CheckSquare className="h-4 w-4 text-teal-600" />
                            ) : (
                              <Square className="h-4 w-4 text-slate-350" />
                            )}
                            <div className="text-right">
                              <h4 className="text-[11px] font-black">{usr.userName}</h4>
                              <p className="text-[9.5px] font-mono text-slate-400 leading-none mt-0.5 select-all">{usr.userEmail}</p>
                            </div>
                          </div>
                          <span className={`text-[8.5px] font-bold rounded px-1.5 py-0.5 ${
                            usr.role === 'admin' ? 'bg-red-50 text-red-600' : 'bg-slate-100 text-slate-600'
                          }`}>
                            {usr.role === 'admin' ? 'مدير' : 'منتسب'}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* History table of past notifications */}
          <div className="rounded-2xl border border-slate-150 bg-white shadow-xs overflow-hidden">
            <div className="p-4 bg-slate-50 border-b flex items-center justify-between">
              <button 
                onClick={fetchNotifHistory} 
                className="p-1 px-2 border hover:bg-white rounded-lg transition text-[10px] font-bold text-slate-500 cursor-pointer flex items-center gap-1"
              >
                <RefreshCw className="h-3 w-3 animate-spin duration-1000" />
                <span>تحديث الجدول</span>
              </button>
              <h3 className="text-xs font-black text-slate-800">أرشيف الإشعارات الإدارية السابقة والمقروءة</h3>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-right text-xs">
                <thead>
                  <tr className="bg-slate-100 border-b text-gray-500 font-bold">
                    <th className="p-4">العنوان والتفاصيل</th>
                    <th className="p-4 text-center">التصنيف</th>
                    <th className="p-4 text-center">طريقة الإرسال</th>
                    <th className="p-4 text-center">المستهدفين</th>
                    <th className="p-4 text-center">تمت القراءة من</th>
                    <th className="p-4 text-center">تاريخ النشر</th>
                  </tr>
                </thead>
                <tbody className="divide-y text-slate-700">
                  {isLoading ? (
                    <tr>
                      <td colSpan={6} className="p-8 text-center text-gray-400 font-bold">
                        جاري جلب الأرشيف...
                      </td>
                    </tr>
                  ) : notifHistory.length > 0 ? (
                    notifHistory.map((notif: any) => {
                      const readCount = notif.isRead ? notif.isRead.length : 0;
                      return (
                        <tr key={notif.id} className="hover:bg-slate-50/50 transition border-slate-100">
                          <td className="p-4 max-w-sm">
                            <h4 className="font-extrabold text-slate-900 select-all">{notif.title}</h4>
                            <p className="text-[10.5px] text-slate-450 truncate mt-1 leading-normal">{notif.description}</p>
                          </td>
                          <td className="p-4 text-center">
                            <span className={`rounded-md px-2 py-0.75 text-[9px] font-bold uppercase ${
                              notif.type === 'update' ? 'bg-teal-50 text-teal-700' :
                              notif.type === 'alert' ? 'bg-red-50 text-red-700' :
                              notif.type === 'announcement' ? 'bg-sky-50 text-sky-700' :
                              'bg-amber-50 text-amber-700'
                            }`}>
                              {notif.type === 'update' ? 'تحديث خادم' :
                               notif.type === 'alert' ? 'تنبيه عاجل' :
                               notif.type === 'announcement' ? 'إعلان عام' :
                               'أعمال صيانة'}
                            </span>
                          </td>
                          <td className="p-4 text-center text-slate-500 font-bold">
                            {notif.sendMethod === 'internal' ? 'داخلي بالمنصة' :
                             notif.sendMethod === 'email' ? 'Trigger Email' : 'الكل (مشترك)'}
                          </td>
                          <td className="p-4 text-center text-[10.5px] font-medium text-slate-600">
                            {notif.targetUsers === 'all' || !notif.targetUsers ? (
                              <span className="bg-emerald-50 text-emerald-800 rounded px-1.5 py-0.5 font-bold">الجميع عموماً</span>
                            ) : (
                              <span className="bg-indigo-50 text-indigo-800 rounded px-1.5 py-0.5 font-bold">
                                {Array.isArray(notif.targetUsers) ? notif.targetUsers.length : 1} مستخدمين محددين
                              </span>
                            )}
                          </td>
                          <td className="p-4 text-center font-mono">
                            <span className="font-black text-teal-700 text-sm">{readCount}</span>
                            <span className="text-[10px] text-gray-400 font-bold"> مشاركين</span>
                          </td>
                          <td className="p-4 text-center text-gray-400 font-mono text-[10.5px]">
                            {new Date(notif.createdAt).toLocaleDateString('ar-IQ')}
                          </td>
                        </tr>
                      );
                    })
                  ) : (
                    <tr>
                      <td colSpan={6} className="p-8 text-center text-gray-400 font-bold">
                        لا توجد أي إشعارات إدارية مرسلة سابقة في السجل.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Modal Preview Dialog before transmission */}
          {isPreviewing && (
            <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-xs z-100 flex items-center justify-center p-4">
              <div className="bg-slate-100 border border-slate-200 rounded-3xl w-full max-w-4xl p-6 shadow-2xl relative max-h-[85vh] overflow-y-auto" dir="rtl text-right">
                {/* Header preview bar */}
                <div className="flex items-center justify-between border-b border-slate-200 pb-3 mb-5">
                  <button
                    onClick={() => setIsPreviewing(false)}
                    className="p-1 px-3 border hover:bg-slate-200 rounded-lg text-slate-500 transition font-bold text-xs shrink-0 cursor-pointer"
                  >
                    إغلاق المعاينة والرجوع
                  </button>
                  <h3 className="text-sm font-black text-slate-800 flex items-center gap-1">
                    <Send className="h-4 w-4 text-teal-600 animate-pulse" />
                    <span>مراجعة المستند ونمط الإشعار المعتمد للبث</span>
                  </h3>
                </div>

                <div className="grid gap-6 md:grid-cols-2 text-right">
                  {/* 1. In-App Template View Mockup */}
                  <div className="space-y-3">
                    <span className="text-[10px] font-bold text-teal-600 block bg-teal-50 rounded px-2 py-1 select-none text-right">
                      (معاينة الجزء 1) - تصميم بطاقة الإشعار المباشر (داخلي) في جرس المنصة للمستخدم:
                    </span>
                    <div className="p-5 rounded-2xl border border-slate-250 bg-white shadow-md flex gap-4 text-right justify-start">
                      <span className={`p-3 h-12 w-12 shrink-0 rounded-xl flex items-center justify-center ${
                        notifType === 'update' ? 'text-teal-600 bg-teal-50' :
                        notifType === 'alert' ? 'text-red-600 bg-red-50' :
                        notifType === 'announcement' ? 'text-sky-600 bg-sky-50' :
                        'text-amber-600 bg-amber-50'
                      }`}>
                        {notifType === 'update' ? <Award className="h-5 w-5" /> :
                         notifType === 'alert' ? <Clock className="h-5 w-5" /> :
                         notifType === 'announcement' ? <BookOpen className="h-5 w-5" /> :
                         <Wrench className="h-5 w-5" />}
                      </span>

                      <div className="space-y-1 flex-1 min-w-0 text-right">
                        <div className="flex justify-between items-center flex-row-reverse">
                          <h4 className="text-xs font-black text-slate-900 truncate">
                            {notifTitle || 'عنوان الإشعار يكتب هنا'}
                          </h4>
                          <span className="h-1.5 w-1.5 rounded-full bg-teal-500 shrink-0"></span>
                        </div>
                        <p className="text-[10.5px] text-slate-500 leading-normal line-clamp-3">
                          {notifMessage || 'محتوى ونصوص التعميم الإداري المعاين للتوزيع...'}
                        </p>
                        <span className="text-[8.5px] text-slate-400 font-bold block pt-1 font-mono">الآن | بواسطة المسؤول العام بقاعدة Firestore</span>
                      </div>
                    </div>
                  </div>

                  {/* 2. Professional Arabic Styled Email Template View Mockup */}
                  <div className="space-y-3">
                    <span className="text-[10px] font-bold text-sky-600 block bg-sky-50 rounded px-2 py-1 select-none text-right">
                      (معاينة الجزء 2) - تصميم الإيميل للمستخدم بقالب الهيئة (Firebase Extensions Trigger):
                    </span>
                    <div className="p-5 rounded-2xl border border-slate-250 bg-slate-50 shadow-md text-right font-sans max-h-72 overflow-y-auto">
                      <div className="bg-white rounded-xl p-5 border border-slate-200 text-right space-y-4">
                        {/* Logo header */}
                        <div className="text-center pb-3 border-b border-slate-100 flex flex-col items-center">
                          <span className="h-10 w-10 text-teal-600 bg-teal-50 rounded-xl flex items-center justify-center font-bold">GP</span>
                          <h3 className="text-xs font-black text-slate-900 mt-1">المنصة الهندسية الكيميائية بالبصرة</h3>
                          <p className="text-[9px] text-teal-500 font-bold">بوابة التعليم والتمثيل الرسمي</p>
                        </div>

                        {/* Title block */}
                        <div className="space-y-1.5 text-right">
                          <h2 className="text-sm font-black text-teal-850 text-right leading-tight">{notifTitle || 'عنوان الإشعار المكتوب والمقرر'}</h2>
                          <div className="h-0.5 w-16 bg-teal-500 rounded-full mr-0 ml-auto"></div>
                        </div>

                        {/* Message contextual content */}
                        <p className="text-xs text-slate-700 leading-relaxed font-normal whitespace-pre-line text-right">
                          {notifMessage || 'محتوى الرسالة الهندسية المخصصة للمستخدم باللغة العربية بأسلوب راق ومحكم.'}
                        </p>

                        <div className="p-3 bg-teal-50 rounded-lg text-center text-[10px] border border-teal-100 leading-normal font-sans">
                          لقد تم إرسال هذا البريد تلقائياً إلى بريدك المسجل في البوابة الهندسية تفعيلاً لنظام الربط ومتابعة نشاطات الهيئة.
                        </div>

                        {/* Platform Action Button */}
                        <div className="text-center pt-3">
                          <a
                            href="/"
                            onClick={(e) => e.preventDefault()}
                            className="bg-teal-600 text-slate-950 px-5 py-2 rounded-xl text-xs font-black shadow-md block w-full hover:bg-teal-700 transition"
                          >
                            اذهب للمنصة وانضم للحوار المباشر ↗
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Confirm Dispatch and Submit Button */}
                <div className="mt-8 border-t pt-4 flex gap-3 text-right">
                  <button
                    onClick={async () => {
                      setIsSendingNotif(true);
                      try {
                        await fsApi.createNotification({
                          title: notifTitle,
                          titleEn: notifTitle,
                          description: notifMessage,
                          descriptionEn: notifMessage,
                          type: notifType,
                          targetUsers: notifTarget === 'all' ? 'all' : notifSelectedUsers
                        });

                        setNotifTitle('');
                        setNotifMessage('');
                        setNotifType('update');
                        setNotifTarget('all');
                        setNotifSelectedUsers([]);
                        setNotifSendMethod('both');
                        setIsPreviewing(false);
                        fetchNotifHistory();

                        alert(lang === 'ar' ? 'تم نشر الإشعار داخل التطبيق بنجاح! (لا يوجد خادم بريد لإرسال نسخة بالإيميل على هذا النشر)' : 'Notification published in-app! (No email server on this deployment to also send it by email)');
                      } catch (err: any) {
                        console.error(err);
                        alert('Error: ' + (err.message || err));
                      } finally {
                        setIsSendingNotif(false);
                      }
                    }}
                    disabled={isSendingNotif}
                    className="flex-1 bg-teal-600 hover:bg-teal-700 font-extrabold text-slate-950 text-xs py-3.5 rounded-xl transition cursor-pointer flex items-center justify-center gap-2 shadow-md shadow-teal-500/15"
                  >
                    {isSendingNotif ? (
                      <RefreshCw className="h-4 w-4 animate-spin" />
                    ) : (
                      <>
                        <Send className="h-4 w-4" />
                        <span>نشر وتوثيق الإشعار عبر قاعدة البيانات والبريد فوراّ ✅</span>
                      </>
                    )}
                  </button>

                  <button
                    onClick={() => setIsPreviewing(false)}
                    className="p-1 px-4 border bg-white hover:bg-slate-50 text-slate-605 rounded-xl transition text-xs font-black cursor-pointer shadow-xs"
                  >
                    تعديل المحتوى
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
