/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { Bell, BellRing, Check, CheckCheck, Award, BookOpen, Monitor, Info, X, ShieldAlert, Smartphone } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { AppNotification, User } from '../types';
import { triggerToast } from './ToastContainer';
import * as fsApi from '../lib/firestoreApi';

interface HeaderNotificationsProps {
  currentUser: User | null;
  lang: 'ar' | 'en' | 'de' | 'es';
  onNavigate?: (section: string) => void;
}

export default function HeaderNotifications({ currentUser, lang, onNavigate }: HeaderNotificationsProps) {
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [readIds, setReadIds] = useState<string[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const [notificationPermission, setNotificationPermission] = useState<string>('default');
  const dropdownRef = useRef<HTMLDivElement>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Simulation state for creating notification from inside the bell
  const [isSimulating, setIsSimulating] = useState(false);
  const [simTextAr, setSimTextAr] = useState('');
  const [simDescAr, setSimDescAr] = useState('');

  // Translations
  const isAr = lang === 'ar';
  const t = {
    title: isAr ? 'الإشعارات والتنبيهات المباشرة' : 'Direct System Alerts',
    markAllRead: isAr ? 'تحديد الكل كمقروء' : 'Mark all as read',
    noNotif: isAr ? 'لا توجد إشعارات جديدة حالياً' : 'No alerts available currently',
    enablePush: isAr ? 'تفعيل التنبيهات الخارجية' : 'Enable External Alerts',
    pushActive: isAr ? 'التنبيهات الخارجية منشطة' : 'External alerts active',
    pushBlocked: isAr ? 'منعت تنبيهات المتصفح' : 'Browser push blocked',
    newCourseAlert: isAr ? 'إشعار بمقعد تدريبي متاح' : 'Training Opportunity Posted',
    newResourceAlert: isAr ? 'ملخص أو مرجع جديد متوفر' : 'New Reference Added',
    broadcastTitle: isAr ? 'أرسل تنبيه عام للمستخدمين' : 'Broadcast General Alert',
    titleLabel: isAr ? 'عنوان الإشعار (بالعربية)' : 'Alert Title (Ar)',
    descLabel: isAr ? 'مضمون والتفاصيل الهندسية' : 'Content & Engineering Details',
    sendBtn: isAr ? 'إرسال ونشر الإشعار فورا' : 'Publish & Broadcast',
    notifType: isAr ? 'تصنيف الإشعار' : 'Alert Level/Tag'
  };

  // Load read notifications from local storage on mount
  useEffect(() => {
    try {
      const stored = localStorage.getItem('gce_read_notification_ids');
      if (stored) {
        setReadIds(JSON.parse(stored));
      }
    } catch (e) {
      console.error('Error reading localStorage', e);
    }

    // Set initial browser notification permission state
    if ('Notification' in window) {
      setNotificationPermission(Notification.permission);
    }
  }, []);

  const notificationsRef = useRef<AppNotification[]>([]);

  // Keep notifications list synced in a ref to avoid dependency re-renders
  useEffect(() => {
    notificationsRef.current = notifications;
  }, [notifications]);

  // Fetch notifications helper
  const fetchNotifications = async (triggerAlert = false) => {
    try {
      const data = await fsApi.fetchNotifications();

      // Check for completely new notifications to push standard HTML5 browser alerts and in-app toasts
      const currentNotifs = notificationsRef.current;
      if (triggerAlert && data.length > 0 && currentNotifs.length > 0) {
        const oldIds = new Set(currentNotifs.map(n => n.id));
        const brandNewList = data.filter(n => !oldIds.has(n.id));

        brandNewList.forEach(item => {
          // Trigger in-app Toast notification
          triggerToast({
            id: item.id,
            title: item.title,
            titleEn: item.titleEn,
            description: item.description,
            descriptionEn: item.descriptionEn,
            type: (item.type === 'alert' ? 'error' : item.type === 'maintenance' ? 'success' : 'general') as any
          });
          // Trigger browser system notification (External)
          triggerExternalPush(item);
        });

        if (brandNewList.length > 0) {
          // Play a gentle notification sound using standard synth audio API (offline friendly!)
          triggerNotificationBeep();
        }
      }
      setNotifications(data);
    } catch (err) {
      console.error('Failed to fetch notifications', err);
    }
  };

  // Polling for real-time notifications updates
  useEffect(() => {
    fetchNotifications(false);
    
    // Polling every 15 seconds is robust and does not cause network load/exhaustion
    const interval = setInterval(() => {
      fetchNotifications(true);
    }, 15000);

    return () => clearInterval(interval);
  }, []);

  // Handle clicking outside to close
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Browser External Notification Trigger
  const triggerExternalPush = (notif: AppNotification) => {
    if ('Notification' in window && Notification.permission === 'granted') {
      const title = isAr ? notif.title : (notif.titleEn || notif.title);
      const text = isAr ? notif.description : (notif.descriptionEn || notif.description);
      try {
        new Notification(title, {
          body: text,
          icon: 'https://images.unsplash.com/photo-1541888946425-d81bb19240f5?w=128',
          tag: notif.id
        });
      } catch (err) {
        console.error('HTML5 Notification instantiation error:', err);
      }
    }
  };

  // Gentle synth notification beep so it's fully self-contained
  const triggerNotificationBeep = () => {
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(587.33, audioCtx.currentTime); // D5 note
      osc.frequency.exponentialRampToValueAtTime(880, audioCtx.currentTime + 0.15); // A5 note
      
      gain.gain.setValueAtTime(0.08, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.3);
      
      osc.start();
      osc.stop(audioCtx.currentTime + 0.35);
    } catch (e) {
      console.warn('Audio Context beep prevented or unsupported by browser sandbox.', e);
    }
  };

  // Request browser permission for external notifications
  const requestExternalPermission = async () => {
    if (!('Notification' in window)) {
      alert(isAr ? 'المتصفح الخاص بك لا يدعم التنبيهات الخارجية.' : 'Notification API is unsupported on this browser.');
      return;
    }

    const permission = await Notification.requestPermission();
    setNotificationPermission(permission);
    
    if (permission === 'granted') {
      // Direct sample push to demonstrate functionality immediately
      try {
        new Notification(
          isAr ? 'تم تفعيل الإشعار الخارجي بنجاح ✅' : 'External Alerts Enabled ✅',
          {
            body: isAr 
              ? 'ستتلقى الآن تنبيهات على سطح المكتب فور نشر الهيئة العامة لأخبار أو حقائب هندسية جديدة!'
              : 'You will now receive automatic platform messages directly on your desktop device!',
            icon: 'https://images.unsplash.com/photo-1541888946425-d81bb19240f5?w=128'
          }
        );
      } catch (err) {
        console.error('HTML5 Notification instantiation error:', err);
      }
      triggerNotificationBeep();
    }
  };

  // Mark single as read
  const markAsRead = (id: string) => {
    if (!readIds.includes(id)) {
      const updated = [...readIds, id];
      setReadIds(updated);
      localStorage.setItem('gce_read_notification_ids', JSON.stringify(updated));
    }
  };

  // Mark all as read
  const markAllAsRead = () => {
    const allIds = notifications.map(n => n.id);
    setReadIds(allIds);
    localStorage.setItem('gce_read_notification_ids', JSON.stringify(allIds));
  };

  // Submit dynamic notification as Admin or Tester (Fulfilling general user trigger)
  const handleCreateNotification = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!simTextAr || !simDescAr) return;

    try {
      await fsApi.createNotification({
        title: simTextAr,
        titleEn: simTextAr,
        description: simDescAr,
        descriptionEn: simDescAr,
        type: 'general'
      });
      setSimTextAr('');
      setSimDescAr('');
      setIsSimulating(false);
      fetchNotifications(true);
    } catch (err: any) {
      console.error('Error creating custom notification', err);
      triggerToast({
        title: isAr ? 'غير مسموح' : 'Not allowed',
        description: isAr ? 'إرسال الإشعارات العامة متاح فقط لحسابات الأدمن.' : 'Only admin accounts can broadcast notifications.',
        type: 'error'
      });
    }
  };

  const unreadCount = notifications.filter(n => !readIds.includes(n.id)).length;

  return (
    <div className="relative" ref={dropdownRef} id="header-notifications-widget">
      {/* Interactive Bell Icon Trigger Button */}
      <button
        onClick={() => {
          setIsOpen(!isOpen);
          if (!isOpen && unreadCount > 0) {
            // mark current view as clicked or wait individual
          }
        }}
        className="relative p-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 hover:text-teal-600 dark:hover:text-teal-400 transition cursor-pointer flex items-center justify-center focus:outline-none"
        aria-label="System Notifications Bell"
        id="notification-bell-btn"
      >
        {unreadCount > 0 ? (
          <motion.div
            animate={{ rotate: [0, 15, -15, 10, -10, 0] }}
            transition={{ repeat: Infinity, duration: 2, repeatDelay: 4 }}
          >
            <BellRing className="h-5 w-5 text-teal-600 dark:text-teal-400 animate-pulse" />
          </motion.div>
        ) : (
          <Bell className="h-5 w-5" />
        )}

        {/* Counter Badge bubble */}
        {unreadCount > 0 && (
          <span className="absolute -top-1 -right-1 flex h-4.5 w-4.5 items-center justify-center rounded-full bg-red-500 text-[10px] font-black text-white ring-2 ring-white dark:ring-slate-950 animate-bounce">
            {unreadCount}
          </span>
        )}
      </button>

      {/* Popover Dropdown Panel */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.95 }}
            transition={{ duration: 0.15 }}
            className={`absolute z-50 mt-2 w-80 sm:w-96 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xl overflow-hidden ${
              isAr ? 'left-0 origin-top-left' : 'right-0 origin-top-right'
            }`}
          >
            {/* Dropdown Header bar */}
            <div className="p-4 border-b border-slate-100 dark:border-slate-800/80 flex items-center justify-between bg-slate-50 dark:bg-slate-900/60">
              <div className="flex items-center gap-2">
                <BellRing className="h-4.5 w-4.5 text-teal-500" />
                <span className="text-xs font-black text-slate-950 dark:text-white">{t.title}</span>
              </div>
              {unreadCount > 0 && (
                <button
                  onClick={markAllAsRead}
                  className="text-[10px] bg-teal-500/10 hover:bg-teal-500/20 text-teal-600 dark:text-teal-400 font-bold px-2.5 py-1 rounded-md transition cursor-pointer"
                >
                  {t.markAllRead}
                </button>
              )}
            </div>

            {/* External Notifications Status Bar */}
            <div className="px-4 py-2.5 bg-slate-100/50 dark:bg-slate-950/40 border-b border-indigo-500/10 flex items-center justify-between">
              <div className="flex items-center gap-1.5 min-w-0">
                <Smartphone className="h-3.5 w-3.5 text-slate-400 shrink-0" />
                <span className="text-[9px] text-slate-500 truncate">
                  {notificationPermission === 'granted' 
                    ? t.pushActive 
                    : notificationPermission === 'denied' 
                      ? t.pushBlocked 
                      : isAr ? 'استلام التنبيهات على الهاتف أو الديسك توب' : 'Receive alerts on desktop / screen'}
                </span>
              </div>
              {notificationPermission !== 'granted' && (
                <button
                  onClick={requestExternalPermission}
                  className="text-[8.5px] bg-teal-600 text-white hover:bg-teal-700 px-2 py-0.5 rounded-sm font-bold transition whitespace-nowrap cursor-pointer"
                >
                  {t.enablePush}
                </button>
              )}
            </div>

            {/* Notifications Alert List scroll panel */}
            <div className="max-h-[300px] overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800/50">
              {notifications.length === 0 ? (
                <div className="p-8 text-center text-slate-400 dark:text-slate-505">
                  <Bell className="h-8 w-8 mx-auto text-slate-300 dark:text-slate-700 mb-2" />
                  <p className="text-xs font-semibold">{t.noNotif}</p>
                </div>
              ) : (
                notifications.map((notif) => {
                  const isRead = readIds.includes(notif.id);
                  const Icon = notif.type === 'course' ? Award : notif.type === 'resource' ? BookOpen : notif.type === 'platform' ? Monitor : Info;
                  const iconColors = 
                    notif.type === 'course' ? 'text-teal-500 bg-teal-50 dark:bg-teal-950/20' : 
                    notif.type === 'resource' ? 'text-cyan-500 bg-cyan-50 dark:bg-cyan-950/20' :
                    notif.type === 'platform' ? 'text-emerald-500 bg-emerald-50 dark:bg-emerald-950/30' :
                    'text-amber-500 bg-amber-50 dark:bg-amber-955/20';

                  return (
                    <div
                      key={notif.id}
                      onClick={() => markAsRead(notif.id)}
                      className={`p-4 transition cursor-pointer flex gap-3 text-start hover:bg-slate-50 dark:hover:bg-slate-800/20 ${
                        !isRead ? 'bg-teal-500/5 border-l-2 border-teal-500 dark:border-teal-400' : ''
                      }`}
                    >
                      <span className={`p-2.5 h-10 w-10 shrink-0 rounded-xl flex items-center justify-center ${iconColors}`}>
                        <Icon className="h-5 w-5" />
                      </span>
                      <div className="space-y-1 min-w-0 flex-1">
                        <div className="flex items-start justify-between gap-1">
                          <h4 className={`text-xs font-extrabold truncate text-slate-900 dark:text-white`}>
                            {isAr ? notif.title : (notif.titleEn || notif.title)}
                          </h4>
                          {!isRead && (
                            <span className="h-1.5 w-1.5 rounded-full bg-teal-500 shrink-0 mt-1"></span>
                          )}
                        </div>
                        <p className="text-[10px] text-slate-500 dark:text-slate-400 leading-normal line-clamp-2">
                          {isAr ? notif.description : (notif.descriptionEn || notif.description)}
                        </p>
                        <span className="text-[8.5px] text-slate-450 dark:text-slate-500 font-bold block">
                          {new Date(notif.createdAt).toLocaleDateString(isAr ? 'ar-IQ' : 'en-US', {
                            month: 'short',
                            day: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {onNavigate && (
              <div className="p-2.5 border-t border-slate-100 dark:border-slate-800 bg-teal-500/5 text-center">
                <button
                  onClick={() => {
                    onNavigate('notifications');
                    setIsOpen(false);
                  }}
                  className="w-full text-center text-xs font-black text-teal-600 dark:text-teal-400 hover:underline py-1 flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <BellRing className="h-4 w-4" />
                  <span>{isAr ? 'عرض جميع الإشعارات' : 'View All Notifications'}</span>
                </button>
              </div>
            )}

            {/* Lower panel - Trigger manual notifications form for admins or testing purposes */}
            <div className="p-3 bg-slate-50 dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800/80">
              {!isSimulating ? (
                <button
                  onClick={() => setIsSimulating(true)}
                  className="w-full text-center text-[10px] font-bold text-teal-600 dark:text-teal-400 hover:underline py-1 flex items-center justify-center gap-1 cursor-pointer"
                >
                  <ShieldAlert className="h-3.5 w-3.5" />
                  {isAr ? 'إرسال إشعار اختبار لعامة المستخدمين' : 'Send test alert to all users'}
                </button>
              ) : (
                <form onSubmit={handleCreateNotification} className="space-y-2 mt-1">
                  <div className="flex items-center justify-between">
                    <span className="text-[9px] font-black text-rose-500 dark:text-rose-400 flex items-center gap-1 uppercase">
                      <ShieldAlert className="h-3 w-3" />
                      {t.broadcastTitle}
                    </span>
                    <button
                      type="button"
                      onClick={() => setIsSimulating(false)}
                      className="p-1 text-slate-400 hover:text-slate-600"
                    >
                      <X className="h-3.5 w-3.5" />
                    </button>
                  </div>
                  <div>
                    <input
                      type="text"
                      placeholder={t.titleLabel}
                      value={simTextAr}
                      onChange={(e) => setSimTextAr(e.target.value)}
                      className="w-full p-2 text-[10px] rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-teal-500"
                      required
                    />
                  </div>
                  <div>
                    <textarea
                      placeholder={t.descLabel}
                      value={simDescAr}
                      onChange={(e) => setSimDescAr(e.target.value)}
                      className="w-full p-2 text-[9.5px] h-12 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-800 dark:text-slate-300 focus:outline-none focus:ring-1 focus:ring-teal-500 resize-none"
                      required
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full bg-teal-500 hover:bg-teal-600 text-slate-950 font-extrabold text-[10px] py-1.5 px-3 rounded-lg transition cursor-pointer"
                  >
                    {t.sendBtn}
                  </button>
                </form>
              )}
            </div>

          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
