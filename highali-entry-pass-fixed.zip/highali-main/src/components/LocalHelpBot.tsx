/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { MessageSquare, X, Send, HelpCircle, ArrowRight, Sparkles, Book, ShieldAlert, Monitor, Download, Info } from 'lucide-react';
import { LanguageType } from '../locales';

interface LocalHelpBotProps {
  lang: LanguageType;
}

interface FAQItem {
  id: string;
  category: string;
  question: string;
  answer: string;
}

export default function LocalHelpBot({ lang }: LocalHelpBotProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [chatHistory, setChatHistory] = useState<{ sender: 'user' | 'bot'; text: string; time: string }[]>([]);
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [showNotificationBadge, setShowNotificationBadge] = useState(true);

  // Localization resources for helper bot
  const botTranslations: Record<LanguageType, {
    title: string;
    subtitle: string;
    badgeLabel: string;
    welcomeMsg: string;
    askPlaceholder: string;
    faqHeader: string;
    resetBtn: string;
    allCategories: string;
    contactInfo: string;
    categories: {
      auth?: string;
      download: string;
      labs: string;
      pwa: string;
      contact: string;
    };
  }> = {
    ar: {
      title: 'مساعد الهيئة الرقمي',
      subtitle: 'دليل مبرمج فوري لمساعدتك داخل المنصة',
      badgeLabel: 'دعم المنصة',
      welcomeMsg: 'أهلاً بك! أنا المساعد الرقمي المبرمج للهيئة العامة بالبصرة. اختر تصنيفاً أو سؤالاً من القائمة للإجابة الفورية وتسهيل تصفحك:',
      askPlaceholder: 'اختر أحد الأسئلة المتاحة بالأسفل...',
      faqHeader: 'الأسئلة الأكثر شيوعاً وعمليات التوجيه:',
      resetBtn: 'العودة للتصنيفات الرئيسية',
      allCategories: 'التصنيفات الرئيسية للمساعدة',
      contactInfo: 'يمكنك دوماً التواصل مع الهيئة أو مسؤولي الدعم من خلال القنوات والروابط ومجموعات التليجرام الرسمية المتاحة بقسم "قنوات وحسابات الهيئة".',
      categories: {
        download: '📚 تحميل المصادر والكتب الضخمة',
        labs: '🧪 تشغيل المختبرات ومحاكي الذاكر',
        pwa: '📱 تنصيب التطبيق PWA',
        contact: '📞 أرقام التواصل والدعم الفني'
      }
    },
    en: {
      title: 'Digital Authority Assistant',
      subtitle: 'Programmed Instant Guide & FAQs',
      badgeLabel: 'Platform Guide',
      welcomeMsg: 'Hello! I am the automated digital assistant for GCE Basra. Please select a category or click a question to receive instant pre-programmed guidance:',
      askPlaceholder: 'Please select a question below...',
      faqHeader: 'Frequently Asked Questions:',
      resetBtn: 'Back to Primary Categories',
      allCategories: 'Help Categories',
      contactInfo: 'You can always reach out directly through our official social networks, and Telegram support groups available in the accounts section.',
      categories: {
        download: '📚 Heavy reference downloads (400MB+)',
        labs: '🧪 Navigating labs & Thaker AI',
        pwa: '📱 Install as PWA App',
        contact: '📞 Support Lines & Media Desk'
      }
    },
    de: {
      title: 'Digitaler GCE Helfer',
      subtitle: 'Vorprogrammierte Schnellhilfe & FAQ',
      badgeLabel: 'Hilfe-Bot',
      welcomeMsg: 'Hallo! Ich bin der programmierte Helfer für GCE Basra. Wählen Sie eine Kategorie oder eine Frage aus, um sofortige Antworten zu erhalten:',
      askPlaceholder: 'Wählen Sie eine Frage unten aus...',
      faqHeader: 'Häufig gestellte Fragen (FAQs):',
      resetBtn: 'Zurück zu Kategorien',
      allCategories: 'Hilfethemen',
      contactInfo: 'Sie können uns jederzeit über die offiziellen Telegram-Kanäle und Social-Media-Links kontaktieren.',
      categories: {
        download: '📚 Download großer Handbücher (400MB+)',
        labs: '🧪 Labor-Simulatoren & Thaker AI',
        pwa: '📱 GCE PWA-App installieren',
        contact: '📞 Kontaktaufnahme & Vorstand'
      }
    },
    es: {
      title: 'Asistente Digital Corporativo',
      subtitle: 'Guía Programada de FAQs de Basora',
      badgeLabel: 'Guía GCE',
      welcomeMsg: '¡Hola! Soy el asistente digital automatizado del gremio de Basora. Elige una categoría o una pregunta para obtener respuestas inmediatas:',
      askPlaceholder: 'Elige una de las preguntas de abajo...',
      faqHeader: 'Preguntas Frecuentes:',
      resetBtn: 'Volver a Categorías Principales',
      allCategories: 'Categorías de Ayuda',
      contactInfo: 'Siempre puedes contactarnos mediante la sección de "Cuentas oficiales" y canales de Telegram.',
      categories: {
        download: '📚 Descarga de Libros Pesados (400MB+)',
        labs: '🧪 Simuladores Químicos y Thaker AI',
        pwa: '📱 Instalar Aplicación de PWA',
        contact: '📞 Contactos Oficiales y Soporte'
      }
    }
  };

  const t = botTranslations[lang] || botTranslations.ar;

  // Static pre-programmed FAQ dataset
  const faqs: FAQItem[] = [
    // 2. Heavy reference downloads (download)
    {
      id: 'download-1',
      category: 'download',
      question: lang === 'ar' ? 'طريقة تحميل كتاب Perry\'s Handbook وحجمه 400MB+؟'
                : lang === 'en' ? 'How can I download the heavy 400MB+ Perry\'s Chemical Manual?'
                : lang === 'de' ? 'Wie lade ich das über 400MB große Perry\'s Handbuch herunter?'
                : '¿Cómo descargo el libro pesado de Perry de más de 400MB?',
      answer: lang === 'ar'
                ? 'كتاب بيري هو مرجع رئيسي كبير. في قسم "المصادر والكتب المنهجية" ستجد رابط "تحميل من Google Drive" خارجي لسهولة التحميل السريع دون ارهاق المتصفح، مع إمكانية استئناف التحميل عند انقطاع الإنترنت.'
                : lang === 'en'
                ? 'Perry\'s Handbook is a heavy masterpiece. Inside our "Resources & Methodology" tab, we established direct external Google Drive mirror links. This bypasses client-side storage issues, supporting resumable high-speed downloads.'
                : lang === 'de'
                ? 'Das Perry\'s Handbuch ist ein unverzichtbares Standardwerk. Unter "Quellen & Lehrbücher" finden Sie Direktdownload-Links auf Google Drive Spiegelserver, wodurch hohe Download-Geschwindigkeiten garantiert sind.'
                : 'Perry\'s Handbook es un manual masivo. En la pestaña de "Recursos y Módulos", colocamos enlaces directos de Google Drive. Esto agiliza la descarga facilitando la pausa y reanudación.'
    },

    // 3. Navigating labs (labs)
    {
      id: 'labs-1',
      category: 'labs',
      question: lang === 'ar' ? 'كيف أقوم بتشغيل محاكيات المعامل الرقمية ومختبر الصابون؟'
                : lang === 'en' ? 'How do I run the digital chemical labs and detergent simulations?'
                : lang === 'de' ? 'Wie starte ich die digitalen Labore und Seifen-Simulatoren?'
                : '¿Cómo inicio los simuladores de jabones y química digital?',
      answer: lang === 'ar'
                ? 'اذهب إلى قسم "المنصات الرقمية والمختبرات" واختر المختبر المعين. على سبيل المثال، يمنحك "مختبر غاز البصرة" أو "مختبر كيمياء التجميل" أدوات تفاعلية لشرح المواد الخام، وطرق التصنيع واختبار المنتجات.'
                : lang === 'en'
                ? 'Head to the "Digital Labs" section and choose your targeted platform. Labs provide visual, interactive summaries of formulation chemistry, ingredient percentages, and product testing procedures.'
                : lang === 'de'
                ? 'Gehen Sie auf den Reiter "Digitale Online-Plattformen" und wählen Sie das Simulator-Labor aus. Sie erhalten interaktive Anleitungen zu Rohstoffen, Formulierungsschritten und Prüfmethoden.'
                : 'Dirígete a la sección de "Plataformas Digitales" y selecciona el área. Los simuladores muestran descripciones, balances y fórmulas químicas interactivas listas para formular en laboratorio.'
    },
    {
      id: 'labs-2',
      category: 'labs',
      question: lang === 'ar' ? 'ما هي منصة ذاكر لتلخيص الأبحاث، وكيف أستعملها؟'
                : lang === 'en' ? 'What is the "Thaker" AI Research Summarizer, and how does it work?'
                : lang === 'de' ? 'Was ist die "Thaker" KI-Plattform zur Zusammenfassung?'
                : '¿Qué es "Thaker" y cómo funciona el resumidor?',
      answer: lang === 'ar'
                ? 'منصة ذاكر هي محرك متكامل مدمج داخل قسم "المنصات الرقمية". تتيح لك كتابة أو لصق تقارير التجارب أو الأبحاث الكيميائية الطويلة للحصول على تلخيص فوري ومكثف لأهم المعادلات ورموز الأمان وموازين الكتلة.'
                : lang === 'en'
                ? '"Thaker" is our embedded AI summarization portal in the Digital Labs section. You can paste any chemical engineering text or project log, and it will isolate vital formulas, mass-balances, and hazard flags immediately.'
                : lang === 'de'
                ? '"Thaker" ist ein integrierter KI-Textanalysator unter den Labor-Plattformen. Fügen Sie Berichte oder lange Facharbeiten ein, um wichtige Gleichungen, Stoffströme und Sicherheitshinweise herauszufiltern.'
                : '"Thaker" es un sistema integrado en "Plataformas Digitales". Te permite pegar textos de ingeniería largos, identificando al instante fórmulas principales, balances de materia y riesgos químicos.'
    },

    // 4. Install as PWA App (pwa)
    {
      id: 'pwa-1',
      category: 'pwa',
      question: lang === 'ar' ? 'هل يمكنني تثبيت هذه المنصة كتطبيق للجوال أو الحاسوب (PWA)؟'
                : lang === 'en' ? 'Can I install this platform as an app on my phone or computer?'
                : lang === 'de' ? 'Kann ich diese Plattform als App (PWA) auf Mobilgeräten oder PC installieren?'
                : '¿Puedo de verdad instalar la plataforma como una App (PWA)?',
      answer: lang === 'ar'
                ? 'بالتأكيد! لتثبيت تطبيق PWA:\n\n1. انقر على زر "تثبيت المنصة كتبويبة للجهاز" باللون الأخضر المميز أعلى الشاشة.\n2. أو من متصفح كروم / سفاري: اذهب لزر "خيارات" -> ثم اختر "إضافة إلى الشاشة الرئيسية" (Add to Home Screen).\n3. سيعمل التطبيق كبوابة مستقلة وسريعة مع واجهة مستخدم ملائمة.'
                : lang === 'en'
                ? 'Absolutely! To install the platform as a Progressive Web App:\n\n1. Use our prominent "Install PWA App" button displayed at the header bar.\n2. Alternatively, on Mobile Safari / Chrome, tap the Share/Menu icon and select "Add to Home Screen".\n3. Enjoy high speed, clean responsive controls, and offline loading.'
                : lang === 'de'
                ? 'Sicherlich! GCE Basra ist als Progressive Web App (PWA) optimiert:\n\n1. Klicken Sie auf die auffällige "GCE App installieren"-Schaltfläche oben auf der Seite.\n2. Alternativ unter Chrome oder iOS Safari auf "Teilen / Optionen" tippen und "Zum Startbildschirm hinzufügen" wählen.\n3. Das Tool startet daraufhin ohne störende Browserleisten.'
                : '¡Por supuesto! Para instalar esta plataforma como una App nativa ligera:\n\n1. Presiona el botón verde de "Instalar PWA" en la barra de navegación.\n2. O desde Google Chrome o Safari, ve a "Compartir" o "Configuración" y pulsa "Añadir a pantalla de inicio".\n3. Carga más rápido y funciona de forma independiente.'
    },

    // 5. Contact & Support (contact)
    {
      id: 'contact-1',
      category: 'contact',
      question: lang === 'ar' ? 'كيف أتواصل مع هيئة المهندسين الكيميائيين بشكل مباشر؟'
                : lang === 'en' ? 'How do I contact the Basra Chemical Engineers association?'
                : lang === 'de' ? 'Wie erreiche ich den Verband der Chemieingenieure in Basra?'
                : '¿Cómo me comunico directamente con el sindicato?',
      answer: lang === 'ar'
                ? 'نوفر روابط تواصل محدثة ومباشرة في قسم "قنوات وحسابات الهيئة" تشمل تيليجرام، فيسبوك، ومجموعات المهندسين الكيميائيين والمجموعات والممثليات المهنية والتعليمية.'
                : lang === 'en'
                ? 'We list active direct channels in our "Official Channels" section, including Telegram, Facebook, and LinkedIn links to assist you directly.'
                : lang === 'de'
                ? 'Sie finden aktualisierte Direktlinks unter "Plattformkontakte", u.a. Telegram und Facebook.'
                : 'Ofrecemos enlaces oficiales actualizados en la sección para canales oficiales (Telegram, Facebook, LinkedIn, etc.) para consultarnos directamente.'
    }
  ];

  // System greeting message inside hook
  useEffect(() => {
    setChatHistory([
      {
        sender: 'bot',
        text: t.welcomeMsg,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }
    ]);
  }, [lang]);

  const handleSelectFAQ = (item: FAQItem) => {
    const timeNow = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    setChatHistory((prev) => [
      ...prev,
      { sender: 'user', text: item.question, time: timeNow },
      { sender: 'bot', text: item.answer, time: timeNow }
    ]);
    setShowNotificationBadge(false);
  };

  const handleReset = () => {
    setActiveCategory(null);
  };

  // Filter FAQ based on category selection
  const filteredFAQs = activeCategory 
    ? faqs.filter(f => f.category === activeCategory)
    : [];

  return (
    <div className="fixed bottom-6 left-6 z-50 font-sans" dir={lang === 'ar' ? 'rtl' : 'ltr'}>
      {/* Bot Launcher Button with pulsating animation */}
      {!isOpen && (
        <button
          onClick={() => {
            setIsOpen(true);
            setShowNotificationBadge(false);
          }}
          className="flex items-center gap-2.5 rounded-full bg-teal-600 hover:bg-teal-700 text-white p-3.5 md:px-5 md:py-3.5 shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105 active:scale-95 text-xs font-black relative"
          id="local-guide-bot-launcher"
        >
          <MessageSquare className="h-5 w-5 animate-pulse" />
          <span className="hidden md:inline">{t.title}</span>
          
          {showNotificationBadge && (
            <span className="absolute -top-1 -right-1 block h-4 w-4 rounded-full bg-red-500 text-[9px] font-bold text-white flex items-center justify-center animate-bounce">
              1
            </span>
          )}
        </button>
      )}

      {/* Expanded Bot Window */}
      {isOpen && (
        <div 
          className="w-80 md:w-96 rounded-2xl bg-white border border-slate-100 shadow-2xl flex flex-col h-[520px] max-h-[85vh]"
          id="local-guide-bot-window"
        >
          {/* Header */}
          <div className="p-4 rounded-t-2xl bg-gradient-to-br from-slate-900 via-teal-900 to-emerald-950 text-white flex items-center justify-between border-b border-teal-500/25">
            <div className="flex items-center gap-2.5">
              <span className="p-2 rounded-lg bg-teal-600/30 text-teal-400">
                <Sparkles className="h-4 w-4" />
              </span>
              <div>
                <h4 className="text-xs font-black text-white">{t.title}</h4>
                <p className="text-[10px] text-slate-300 leading-none">{t.subtitle}</p>
              </div>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="p-1 rounded-lg hover:bg-white/10 text-slate-300 hover:text-white transition"
              id="close-guide-bot-btn"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          {/* Chat Messages Panel */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50/50">
            {chatHistory.map((msg, i) => (
              <div 
                key={i} 
                className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
              >
                <div 
                  className={`max-w-[85%] rounded-2xl p-3 text-xs leading-relaxed whitespace-pre-wrap ${
                    msg.sender === 'user' 
                      ? 'bg-teal-600 text-white rounded-br-xs' 
                      : 'bg-white border border-slate-100 text-slate-800 rounded-bl-xs'
                  }`}
                >
                  {msg.text}
                </div>
                <span className="text-[9px] text-slate-400 mt-1 px-1 font-mono">{msg.time}</span>
              </div>
            ))}
          </div>

          {/* Preset Questions selection panel (Menu selection) */}
          <div className="p-3 bg-white border-t border-slate-100 space-y-2 max-h-[220px] overflow-y-auto">
            {/* Main Selection state: show Categories */}
            {!activeCategory ? (
              <div className="space-y-1.5">
                <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">
                  {t.allCategories}:
                </span>
                <div className="grid grid-cols-1 gap-1.5">
                  {Object.entries(t.categories).map(([key, label]) => (
                    <button
                      key={key}
                      onClick={() => setActiveCategory(key)}
                      className="w-full text-right bg-slate-50 hover:bg-teal-50 hover:text-teal-900 px-3 py-2 text-xs font-bold rounded-lg border border-slate-100 hover:border-teal-100 transition flex items-center justify-between cursor-pointer"
                    >
                      <span>{label}</span>
                      <ArrowRight className={`h-3 w-3 ${lang === 'ar' ? 'rotate-180' : ''} text-slate-400`} />
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              // Active category: list actual FAQs
              <div className="space-y-1.5">
                <div className="flex items-center justify-between border-b border-slate-150 pb-1.5">
                  <span className="text-[10px] font-black text-teal-700">
                    {t.categories[activeCategory as keyof typeof t.categories]}:
                  </span>
                  <button
                    onClick={handleReset}
                    className="text-[10px] font-bold text-slate-450 hover:text-teal-600 flex items-center gap-1 transition cursor-pointer"
                  >
                    <ArrowRight className="h-3 w-3 rotate-180" />
                    {t.resetBtn}
                  </button>
                </div>

                <div className="space-y-1">
                  {filteredFAQs.map((faq) => (
                    <button
                      key={faq.id}
                      onClick={() => handleSelectFAQ(faq)}
                      className="w-full text-right bg-slate-50 hover:bg-teal-50 px-3 py-2 text-xs font-medium rounded-lg border border-slate-100/50 hover:border-teal-100 text-slate-700 hover:text-teal-950 transition flex gap-1.5 items-start cursor-pointer"
                    >
                      <HelpCircle className="h-3.5 w-3.5 shrink-0 text-teal-500 mt-0.5" />
                      <span>{faq.question}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Bottom static instruction footer */}
          <div className="p-2.5 rounded-b-2xl bg-slate-50 border-t border-slate-150 text-center">
            <p className="text-[9px] text-slate-450 font-bold leading-relaxed">
              💡 {lang === 'ar' ? 'نظام مساعد الهيئة - لا يتطلب إنترنت أو ذكاء اصطناعي' : 'Pre-programmed offline-capable diagnostic guide'}
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
